import { StoreProvider } from "./store";
import { AnnouncementBar } from "./components/AnnouncementBar";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Trust } from "./components/Trust";
import { Categories } from "./components/Categories";
import { FeaturedBrands } from "./components/FeaturedBrands";
import { Products } from "./components/Products";
import { Story } from "./components/Story";
import { Campaign } from "./components/Campaign";
import { Support } from "./components/Support";
import { Footer } from "./components/Footer";
import { QuickView } from "./components/QuickView";
import { SearchOverlay } from "./components/SearchOverlay";
import { EnquiryDrawer } from "./components/EnquiryDrawer";
import { Toast } from "./components/Toast";

export default function App() {
  return (
    <StoreProvider>
      <a
        href="#products"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-full focus:bg-white focus:px-5 focus:py-3 focus:text-sm focus:font-semibold focus:text-ink"
      >
        Skip to products
      </a>
      <AnnouncementBar />
      <Header />
      <main>
        <Hero />
        <Trust />
        <Categories />
        <FeaturedBrands />
        <Products />
        <Story />
        <Campaign />
        <Support />
      </main>
      <Footer />

      <QuickView />
      <SearchOverlay />
      <EnquiryDrawer />
      <Toast />
    </StoreProvider>
  );
}
