/**
 * Albert Pharmaceuticals catalogue — every entry is taken from albertpharma.com
 * (product listing + product detail popups) and the printed pack artwork.
 *
 * NO prices, ratings, discounts or reviews exist on the source site, so none are shown.
 */

export type CategoryId =
  | "anti-infectives"
  | "gastro"
  | "pain"
  | "neuro"
  | "cardio"
  | "consumer";

export interface Category {
  id: CategoryId;
  name: string;
  short: string;
  blurb: string;
}

export interface Product {
  slug: string;
  name: string;
  /** Generic / composition as printed on the pack or the source site */
  generic: string;
  /** Strength + form + pack size as printed on the pack artwork */
  pack: string;
  /** Therapeutic / consumer-healthcare segment as listed on albertpharma.com */
  segment: string;
  category: CategoryId;
  /** "Available as" range as listed on albertpharma.com, when provided */
  range?: string;
  /** Short paraphrase of the indications listed on the source site */
  summary?: string;
  /** Real pack artwork exists? If not, a clearly-marked placeholder pack is rendered */
  hasImage: boolean;
  /** Existing product page on albertpharma.com */
  url: string;
}

export const categories: Category[] = [
  {
    id: "anti-infectives",
    name: "Anti-Infectives",
    short: "Antibiotics & antifungals",
    blurb: "Antibiotic, anti-infective and antifungal therapy.",
  },
  {
    id: "gastro",
    name: "Gastro-Care",
    short: "Ulcer, reflux & spasm",
    blurb: "Anti-ulcerant and anti-spasmodic formulations.",
  },
  {
    id: "pain",
    name: "Pain & Mobility",
    short: "Joints & muscles",
    blurb: "Anti-rheumatic and muscle-relaxant therapy.",
  },
  {
    id: "neuro",
    name: "Mind & Nerves",
    short: "Neuro & mood support",
    blurb: "Anti-convulsant and anti-depressant therapy.",
  },
  {
    id: "cardio",
    name: "Heart, Lungs & Urology",
    short: "Daily specialty care",
    blurb: "Anti-hypertensive, anti-asthmatic and urinary-flow therapy.",
  },
  {
    id: "consumer",
    name: "Consumer Healthcare",
    short: "Women's, men's & nutritional health",
    blurb: "Everyday nutritional and wellness formulations.",
  },
];

const site = (slug: string) => `https://albertpharma.com/${slug}/`;

export const products: Product[] = [
  // ---------- Anti-infectives ----------
  {
    slug: "alzacin",
    name: "Alzacin",
    generic: "Azithromycin",
    pack: "500mg · 6 Tablets",
    segment: "Antibiotic",
    category: "anti-infectives",
    range: "Capsules 250mg · Suspension 200mg/5ml",
    summary:
      "Mild to moderate infections of the respiratory tract, skin and skin structures caused by susceptible organisms.",
    hasImage: true,
    url: site("alzacin"),
  },
  {
    slug: "cixalt",
    name: "Cixalt",
    generic: "Ciprofloxacin",
    pack: "500mg · 10 Tablets",
    segment: "Antibiotic",
    category: "anti-infectives",
    summary:
      "Lower respiratory, urinary and genital tract infections caused by susceptible bacteria.",
    hasImage: true,
    url: site("cixalt"),
  },
  {
    slug: "levobert",
    name: "Levobert",
    generic: "Levofloxacin",
    pack: "250mg · 10 Tablets",
    segment: "Antibiotic",
    category: "anti-infectives",
    summary:
      "Sinusitis, bronchitis, pneumonia, skin and urinary tract infections caused by susceptible organisms.",
    hasImage: true,
    url: site("levobert"),
  },
  {
    slug: "linezert",
    name: "Linezert",
    generic: "Linezolid",
    pack: "400mg · 12 Tablets",
    segment: "Anti-Infective",
    category: "anti-infectives",
    range: "Tablets / Dry suspension 400mg · 600mg · 60ml bottle",
    hasImage: true,
    url: site("linezert"),
  },
  {
    slug: "alfazole",
    name: "Alfazole",
    generic: "Fluconazole",
    pack: "150mg · 1 Capsule",
    segment: "Anti-Fungal",
    category: "anti-infectives",
    range: "Capsule 150mg · Suspension 50mg/5ml",
    summary:
      "Vaginal, oropharyngeal and oesophageal candidiasis, candida urinary tract and systemic infections.",
    hasImage: true,
    url: site("alfazole"),
  },
  {
    slug: "furid",
    name: "Furid",
    generic: "Itraconazole",
    pack: "100mg · 4 Capsules",
    segment: "Anti-Fungal",
    category: "anti-infectives",
    range: "Capsule 100mg",
    summary:
      "Fungal infections including onychomycosis, tinea, pityriasis versicolor and candidiasis.",
    hasImage: true,
    url: site("furid"),
  },

  // ---------- Gastro-care ----------
  {
    slug: "esobert",
    name: "Esobert",
    generic: "Esomeprazole",
    pack: "40mg · 14 Capsules",
    segment: "Anti-Ulcerant",
    category: "gastro",
    range: "Capsules 20mg · 40mg",
    summary:
      "GERD, healing and maintenance of erosive oesophagitis, and NSAID-associated gastric ulcer risk reduction.",
    hasImage: true,
    url: site("esobert"),
  },
  {
    slug: "exocid",
    name: "eXocid",
    generic: "Omeprazole",
    pack: "40mg · 14 Capsules",
    segment: "Anti-Ulcerant",
    category: "gastro",
    hasImage: true,
    url: site("exocid"),
  },
  {
    slug: "fobert",
    name: "Fobert",
    generic: "Famotidine",
    pack: "40mg · 10 Tablets",
    segment: "Anti-Ulcerant",
    category: "gastro",
    range: "Tablet 20mg · 40mg",
    summary:
      "Gastric and duodenal ulcer, reflux oesophagitis, gastritis and other acid hypersecretory conditions.",
    hasImage: true,
    url: site("fobert"),
  },
  {
    slug: "mesodim",
    name: "Mesodim SR",
    generic: "Mebeverine HCl",
    pack: "200mg · 10 Capsules",
    segment: "Anti-Spasmodic",
    category: "gastro",
    range: "Tablet 135mg · Capsule 200mg",
    hasImage: true,
    url: site("mesodim"),
  },

  // ---------- Pain & mobility ----------
  {
    slug: "etogesic",
    name: "Etogesic",
    generic: "Etoricoxib",
    pack: "60mg · 10 Tablets",
    segment: "Anti-Rheumatic",
    category: "pain",
    range: "Tablets 60mg",
    summary:
      "Osteoarthritis, rheumatoid arthritis, ankylosing spondylitis, acute gouty arthritis and acute pain relief.",
    hasImage: true,
    url: site("etogesic"),
  },
  {
    slug: "thicocid",
    name: "Thicocid",
    generic: "Thiocolchicoside",
    pack: "4mg · 10 Capsules",
    segment: "Muscle Relaxant",
    category: "pain",
    range: "Capsules 4mg",
    summary:
      "Acute and chronic lumbar and sciatic pain, cervico-brachial neuralgia, torticollis and post-traumatic pain.",
    hasImage: true,
    url: site("thicocid"),
  },

  // ---------- Mind & nerves ----------
  {
    slug: "baliptic",
    name: "Baliptic",
    generic: "Pregabalin",
    pack: "50mg · 14 Capsules",
    segment: "Anti-Convulsant",
    category: "neuro",
    range: "Capsules 50mg · 75mg · 100mg · 150mg",
    hasImage: true,
    url: site("baliptic"),
  },
  {
    slug: "sprain",
    name: "Sprain",
    generic: "Duloxetine",
    pack: "20mg · 7 Capsules",
    segment: "Anti-Depressant",
    category: "neuro",
    range: "Capsules 20mg · 60mg",
    summary:
      "Major depressive episodes and diabetic peripheral neuropathic pain in adults.",
    hasImage: true,
    url: site("sprain"),
  },
  {
    // NOTE: albertpharma.com lists A-Calm's segment as "Anti-Diabetic", but the printed
    // pack states Escitalopram. We follow the pack. Flagged for the content team.
    slug: "acalm",
    name: "A-Calm",
    generic: "Escitalopram",
    pack: "5mg · 14 Tablets",
    segment: "Anti-Depressant",
    category: "neuro",
    range: "Tablets 5mg · 10mg · 20mg",
    hasImage: true,
    url: site("a-calm"),
  },

  // ---------- Heart, lungs & urology ----------
  {
    slug: "amsapin",
    name: "Amsapin",
    generic: "Amlodipine + Valsartan",
    pack: "5mg/80mg · 14 Tablets",
    segment: "Anti-Hypertensive",
    category: "cardio",
    range: "Tablets 5mg + 80mg",
    summary:
      "Hypertension where blood pressure is not controlled on monotherapy or multiple drugs are needed.",
    hasImage: true,
    url: site("amsapin"),
  },
  {
    slug: "altelu",
    name: "Altelu",
    generic: "Montelukast",
    pack: "10mg · 14 Tablets",
    segment: "Anti-Asthmatic",
    category: "cardio",
    range: "Tablets 10mg",
    summary:
      "Long-term treatment of asthma and allergic rhinitis, and prevention of exercise-induced bronchospasm.",
    hasImage: true,
    url: site("altelu"),
  },
  {
    slug: "taluset",
    name: "Taluset",
    generic: "Tamsulosin HCl",
    pack: "0.4mg · 10 Capsules",
    segment: "Urinary Flow Enhancer",
    category: "cardio",
    range: "Capsules 0.4mg",
    hasImage: true,
    url: site("taluset"),
  },

  // ---------- Consumer healthcare (NO pack artwork available → placeholder pack) ----------
  {
    slug: "mega-z",
    name: "Mega-Z",
    generic: "Omega-3 with vitamins",
    pack: "20 Tablets",
    segment: "Nutritional Health",
    category: "consumer",
    summary:
      "Multivitamin formula with an added Omega-3 (DHA and EPA) from high-purity fish oil.",
    hasImage: false,
    url: site("mega-z"),
  },
  {
    slug: "mpause",
    name: "Mpause",
    generic: "Soy isoflavones 75mg",
    pack: "20 Capsules",
    segment: "Female's Health",
    category: "consumer",
    summary:
      "High-strength soy isoflavone supplement for perimenopause and menopause.",
    hasImage: false,
    url: site("mpause"),
  },
  {
    slug: "riocran",
    name: "Riocran",
    generic: "Cranberry extract 250mg",
    pack: "10 Sachets",
    segment: "Women's Health",
    category: "consumer",
    summary:
      "Cranberry juice extract that helps prevent urinary tract infections.",
    hasImage: false,
    url: site("riocran"),
  },
  {
    slug: "mysitol",
    name: "Mysitol",
    generic: "Myo-Inositol 2000mg + Folic Acid 200mcg",
    pack: "10 Sachets",
    segment: "Women's Health",
    category: "consumer",
    summary:
      "Supports hormonal balance and insulin sensitisation; listed for menstrual irregularities and PCOS.",
    hasImage: false,
    url: site("mysitol"),
  },
  {
    slug: "pair4c-female",
    name: "Pair4C Female",
    generic: "Multivitamin & minerals",
    pack: "20 Tablets",
    segment: "Female's Health",
    category: "consumer",
    summary:
      "Nutrients formulated to help build nutritional stores for pregnancy and support reproductive health.",
    hasImage: false,
    url: site("pair4c-female"),
  },
  {
    slug: "pair4c-male",
    name: "Pair4C Male",
    generic: "Multivitamin & minerals",
    pack: "20 Tablets",
    segment: "Men's Health",
    category: "consumer",
    summary:
      "Multivitamin and minerals formulated for men's reproductive health and healthy conception.",
    hasImage: false,
    url: site("pair4c-male"),
  },
  {
    slug: "omax",
    name: "Omax",
    generic: "Multivitamin, minerals, proteins, essential fats",
    pack: "400g Tin · Powder",
    segment: "Nutritional Health",
    category: "consumer",
    summary:
      "Comprehensive nutritional formula for patients at nutritional risk or recovering from illness or surgery.",
    hasImage: false,
    url: site("omax"),
  },
];

export const getProduct = (slug: string) => products.find((p) => p.slug === slug);
export const getCategory = (id: CategoryId) => categories.find((c) => c.id === id)!;
export const productsIn = (id: CategoryId) => products.filter((p) => p.category === id);

/** Curated order for the "All" view so the strongest pack shots lead */
export const featuredOrder = [
  "esobert",
  "etogesic",
  "alzacin",
  "altelu",
  "fobert",
  "amsapin",
  "mesodim",
  "cixalt",
];

export const company = {
  legal: "Albert Pharmaceuticals (Pvt.) Ltd.",
  tagline: "Heal, Serve, Forever",
  phone: "+92 42 3575 3282",
  phoneHref: "tel:+924235753282",
  email: "contact@albertpharma.com",
  headOffice:
    "https://www.google.com/maps/place/Albert+Pharmaceuticals+(Pvt.)+Ltd./@31.5296585,74.3436112,21z/data=!4m5!3m4!1s0x0:0x599588ecaa76d4e1!8m2!3d31.5296143!4d74.3436414",
  plant:
    "https://www.google.com/maps/place/Albert+Pharmaceuticals+(Pvt.)+Limited/@31.2897975,74.1773875,17z/data=!3m1!4b1!4m5!3m4!1s0x3918548ef3af7bb9:0xbca75c8106455518!8m2!3d31.2897929!4d74.1795762",
  social: {
    facebook: "https://www.facebook.com/AlbertPharm/",
    instagram: "https://www.instagram.com/albertpharm/",
    linkedin: "https://www.linkedin.com/company/28139682",
    twitter: "https://twitter.com/albertpharm",
  },
  site: "https://albertpharma.com",
};
