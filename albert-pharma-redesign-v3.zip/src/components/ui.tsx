import type { CSSProperties, ElementType, ReactNode } from "react";
import { useReveal } from "../hooks";
import { Icon, type IconName } from "./Icon";
import { brandMark, packSources } from "../assets";
import { FallbackImg } from "./FallbackImg";
import type { Product } from "../data/products";

export const cx = (...c: Array<string | false | null | undefined>) => c.filter(Boolean).join(" ");

/* ---------------- Reveal ---------------- */
export function Reveal({
  children,
  delay = 0,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: ElementType;
}) {
  const ref = useReveal<HTMLElement>();
  return (
    <Tag
      ref={ref}
      className={cx("reveal", className)}
      style={{ "--d": `${delay}ms` } as CSSProperties}
    >
      {children}
    </Tag>
  );
}

/* ---------------- Button ---------------- */
type Variant = "primary" | "dark" | "light" | "outline" | "outlineLight";

const variants: Record<Variant, string> = {
  primary: "bg-brand text-white hover:bg-navy",
  dark: "bg-ink text-white hover:bg-brand",
  light: "bg-white text-navy hover:bg-mist",
  outline: "border border-navy/20 text-navy hover:border-navy hover:bg-navy hover:text-white",
  outlineLight: "border border-white/30 text-white hover:bg-white hover:text-navy",
};

interface ButtonProps {
  children: ReactNode;
  variant?: Variant;
  href?: string;
  onClick?: () => void;
  icon?: IconName | null;
  external?: boolean;
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
  size?: "md" | "lg" | "sm";
}

export function Button({
  children,
  variant = "primary",
  href,
  onClick,
  icon = "arrowRight",
  external,
  className,
  type = "button",
  disabled,
  size = "md",
}: ButtonProps) {
  const cls = cx(
    "group inline-flex items-center justify-center gap-2.5 rounded-full font-semibold tracking-[0.005em] whitespace-nowrap",
    "transition-[background-position,background-color,color,border-color,box-shadow,transform] duration-500 ease-[var(--ease-out-expo)]",
    "active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none",
    size === "lg" ? "h-14 px-8 text-[15px]" : size === "sm" ? "h-10 px-5 text-[13px]" : "h-12 px-6 text-sm",
    variants[variant],
    className,
  );
  const inner = (
    <>
      <span>{children}</span>
      {icon && (
        <Icon
          name={icon}
          size={size === "sm" ? 15 : 17}
          className="transition-transform duration-500 ease-[var(--ease-out-expo)] group-hover:translate-x-1"
        />
      )}
    </>
  );
  if (href) {
    return (
      <a
        href={href}
        className={cls}
        onClick={onClick}
        {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      >
        {inner}
      </a>
    );
  }
  return (
    <button type={type} className={cls} onClick={onClick} disabled={disabled}>
      {inner}
    </button>
  );
}

/* ---------------- Product visual ---------------- */
const placeholderTones = [
  "from-[#0a2a4f] to-[#0068b4]",
  "from-[#0a7f9a] to-[#00bfbd]",
  "from-[#0068b4] to-[#37a8ec]",
  "from-[#06182f] to-[#0a4d8c]",
];

/**
 * PLACEHOLDER ASSET — albertpharma.com does not publish pack artwork for the
 * Consumer Healthcare range. This neutral branded carton stands in until
 * photography is supplied. It is intentionally generic (no invented pack design).
 */
export function PackPlaceholder({ product, className }: { product: Product; className?: string }) {
  const tone = placeholderTones[product.slug.length % placeholderTones.length];
  return (
    <div className={cx("relative flex items-center justify-center", className)} role="img" aria-label={`${product.name} — pack artwork coming soon`}>
      <div className="relative aspect-[4/5] w-[46%] min-w-[96px] max-w-[190px]" style={{ perspective: 900 }}>
        <div
          className={cx(
            "absolute inset-0 flex flex-col justify-between overflow-hidden rounded-[10px] bg-gradient-to-br p-[10%] text-white",
            "shadow-[0_28px_40px_-18px_rgba(6,24,47,0.55),0_6px_12px_-6px_rgba(6,24,47,0.35)]",
            tone,
          )}
          style={{ transform: "rotateY(-14deg) rotateX(3deg)" }}
        >
          <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-white/10" />
          <div className="pointer-events-none absolute -bottom-10 -left-6 h-24 w-24 rotate-45 rounded-2xl bg-white/[0.07]" />
          <img src={brandMark} alt="" className="relative h-[17%] w-auto self-start rounded-full" width={32} height={32} />
          <div className="relative">
            <p className="font-display text-[clamp(15px,1.7vw,22px)] font-semibold leading-[1.05] tracking-tight">{product.name}</p>
            <p className="mt-1.5 line-clamp-2 text-[9px] font-medium uppercase leading-snug tracking-[0.12em] text-white/70">
              {product.generic}
            </p>
          </div>
          <p className="relative border-t border-white/20 pt-1.5 text-[8px] font-semibold uppercase tracking-[0.16em] text-white/60">
            Pack artwork soon
          </p>
        </div>
      </div>
    </div>
  );
}

export function ProductVisual({
  product,
  className,
  imgClassName,
  eager,
  sizes,
}: {
  product: Product;
  className?: string;
  imgClassName?: string;
  eager?: boolean;
  sizes?: string;
}) {
  const srcs = packSources(product.slug);
  const placeholder = <PackPlaceholder product={product} className={className} />;
  if (!srcs.length) return placeholder;
  return (
    <div className={cx("flex items-center justify-center", className)}>
      <FallbackImg
        srcs={srcs}
        fallback={placeholder}
        alt={`${product.name} (${product.generic}) ${product.pack} pack`}
        width={720}
        height={560}
        sizes={sizes}
        loading={eager ? "eager" : "lazy"}
        decoding="async"
        referrerPolicy="no-referrer"
        className={cx("h-auto w-full object-contain", imgClassName)}
        draggable={false}
      />
    </div>
  );
}
