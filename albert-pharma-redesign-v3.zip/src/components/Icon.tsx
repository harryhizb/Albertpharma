import type { SVGProps } from "react";

/**
 * Single consistent icon family: 24px grid, 1.6 stroke, round caps.
 */
const paths = {
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.6-3.6" />
    </>
  ),
  bag: (
    <>
      <path d="M5.5 8h13l-1 12.5h-11L5.5 8Z" />
      <path d="M9 8V6.5a3 3 0 0 1 6 0V8" />
    </>
  ),
  menu: <path d="M4 7.5h16M4 12h16M4 16.5h10" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  arrowRight: <path d="M5 12h14m-6-6 6 6-6 6" />,
  arrowUpRight: <path d="M7 17 17 7M8.5 7H17v8.5" />,
  chevronDown: <path d="m6 9 6 6 6-6" />,
  chevronLeft: <path d="m15 6-6 6 6 6" />,
  chevronRight: <path d="m9 6 6 6-6 6" />,
  phone: (
    <path d="M5.5 4h3.2l1.8 4.6-2.2 1.4a11.2 11.2 0 0 0 5.7 5.7l1.4-2.2 4.6 1.8v3.2a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 3.5 6.2 2 2 0 0 1 5.5 4Z" />
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2.5" />
      <path d="m3.5 7.5 8.5 6 8.5-6" />
    </>
  ),
  pin: (
    <>
      <path d="M12 21.5s-7-6-7-11.2a7 7 0 0 1 14 0c0 5.2-7 11.2-7 11.2Z" />
      <circle cx="12" cy="10.2" r="2.5" />
    </>
  ),
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  eye: (
    <>
      <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3 5 5.8v5.4c0 4.4 3 8.2 7 9.8 4-1.6 7-5.4 7-9.8V5.8L12 3Z" />
      <path d="m9 12 2.2 2.2L15.5 10" />
    </>
  ),
  factory: (
    <>
      <path d="M3 20.5V10l6 3.2V10l6 3.2V5.5h3.5a1.5 1.5 0 0 1 1.5 1.5v13.5H3Z" />
      <path d="M8 17h1.5M12.5 17H14M17 17h.5" />
    </>
  ),
  box: (
    <>
      <path d="M12 3 4 7v10l8 4 8-4V7l-8-4Z" />
      <path d="m4 7 8 4 8-4M12 11v10" />
    </>
  ),
  label: (
    <>
      <path d="M4 5.5A1.5 1.5 0 0 1 5.5 4h6.2a1.5 1.5 0 0 1 1.1.4l7 7a1.5 1.5 0 0 1 0 2.1l-5.3 5.3a1.5 1.5 0 0 1-2.1 0l-7-7a1.5 1.5 0 0 1-.4-1.1V5.5Z" />
      <circle cx="8.5" cy="8.5" r="1.2" />
    </>
  ),
  heart: (
    <path d="M12 20s-7.5-4.6-7.5-10.3A4.2 4.2 0 0 1 12 7.2a4.2 4.2 0 0 1 7.5 2.5C19.500 15.400 12 20 12 20Z" />
  ),
  flask: (
    <>
      <path d="M9.5 3h5M10 3v6.2L4.600 18.800A1.700 1.700 0 0 0 6.100 21.300h11.800a1.700 1.700 0 0 0 1.500-2.500L14 9.200V3" />
      <path d="M7.500 15h9" />
    </>
  ),
  send: <path d="m4 11.500 16-7.500-5.800 16-3-6.500L4 11.500Z" />,
  trash: (
    <>
      <path d="M4.500 7h15M9.500 7V4.500h5V7" />
      <path d="m6.500 7 .9 13h9.200l.9-13" />
    </>
  ),
  truck: (
    <>
      <path d="M2.500 6.500h11v10h-11zM13.500 10h4l3 3v3.500h-7" />
      <circle cx="7" cy="17.500" r="1.700" />
      <circle cx="17" cy="17.500" r="1.700" />
    </>
  ),
  headset: (
    <>
      <path d="M4 14v-2a8 8 0 0 1 16 0v2" />
      <rect x="3" y="13.500" width="4" height="6" rx="1.500" />
      <rect x="17" y="13.500" width="4" height="6" rx="1.500" />
      <path d="M19 19.500c0 1.400-1.800 2-4 2" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8.500" r="3.200" />
      <path d="M3 20c0-3.300 2.700-5.500 6-5.500s6 2.200 6 5.500" />
      <path d="M16 5.600a3.200 3.200 0 0 1 0 5.800M18 14.800c1.800.7 3 2.400 3 5.200" />
    </>
  ),
  facebook: (
    <path d="M14.500 8.500V7a1.200 1.200 0 0 1 1.200-1.200H17.500V2.500h-2.800A4.200 4.200 0 0 0 10.500 6.700v1.800H7.500v3.400h3V21.500h4V11.900h2.800l.5-3.400h-3.300Z" />
  ),
  instagram: (
    <>
      <rect x="3.500" y="3.500" width="17" height="17" rx="5" />
      <circle cx="12" cy="12" r="3.800" />
      <path d="M17.200 6.800h.01" />
    </>
  ),
  linkedin: (
    <>
      <path d="M6.500 9.500v8.500M6.500 6v.01M10.500 18v-8.500M10.500 13a3.500 3.500 0 0 1 7 0v5" />
    </>
  ),
  x: <path d="M5 4.500h3.300l10.700 15H15.700L5 4.500ZM18.500 4.500l-6 6.800M5.500 19.500l6-6.600" />,
  command: (
    <path d="M9 9V6.500A2.500 2.500 0 1 0 6.500 9H9Zm0 0h6m-6 0v6m6-6V6.500A2.500 2.500 0 1 1 17.500 9H15Zm0 0v6m0 0h2.500a2.500 2.500 0 1 1-2.500 2.500V15Zm0 0H9m0 0H6.500A2.500 2.500 0 1 0 9 17.500V15Z" />
  ),
} as const;

export type IconName = keyof typeof paths;

interface IconProps extends Omit<SVGProps<SVGSVGElement>, "name"> {
  name: IconName;
  size?: number;
}

export function Icon({ name, size = 20, strokeWidth = 1.6, ...rest }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {paths[name]}
    </svg>
  );
}
