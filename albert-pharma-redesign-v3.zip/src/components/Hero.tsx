import { categories, getProduct, productsIn } from "../data/products";
import { officialFacility, photoCorridor } from "../assets";
import { FallbackImg } from "./FallbackImg";
import { useStore } from "../store";
import { Button, ProductVisual } from "./ui";
import { Icon } from "./Icon";

/**
 * Hero — an editorial "shelf" composition.
 * Left: one statement, built only from counted facts. Right: an arched photo panel (the arch echoes a capsule)
 * with three real packs standing on one shared baseline, overlapping the arch edge. Below: a live index of the
 * six care areas, which replaces the old decorative ticker.
 */
const shelf = [
  { slug: "alzacin", cls: "left-[-4%] w-[46%] bottom-[6%] z-10", delay: 620 },
  { slug: "fobert", cls: "left-[27%] w-[54%] bottom-[0%] z-20", delay: 720 },
  { slug: "etogesic", cls: "right-[-6%] w-[44%] bottom-[7%] z-10", delay: 820 },
] as const;

export function Hero() {
  const { openQuickView, browseCategory } = useStore();

  return (
    <section id="top" className="relative overflow-hidden bg-paper">
      <div className="mx-auto grid max-w-[1440px] gap-10 px-5 pb-0 pt-10 sm:pt-14 lg:grid-cols-[1.08fr_0.92fr] lg:items-center lg:gap-6 lg:px-10 lg:pb-0 lg:pt-12">
        {/* Copy */}
        <div className="relative z-10 lg:pr-6">
          <h1 className="font-display text-[clamp(28px,7.6vw,64px)] font-medium leading-[1.02] tracking-[-0.028em] text-ink min-[1100px]:text-[clamp(52px,4.5vw,68px)]">
            <span className="hero-rise block" style={{ "--d": "60ms" } as React.CSSProperties}>
              Twenty-five medicines.
            </span>
            <span className="hero-rise block" style={{ "--d": "170ms" } as React.CSSProperties}>
              Six areas of care.
            </span>
            <span className="hero-rise block text-brand" style={{ "--d": "280ms" } as React.CSSProperties}>
              One quality policy.
            </span>
          </h1>

          <p className="hero-rise mt-7 max-w-[500px] text-[17px] leading-[1.7] text-slate" style={{ "--d": "400ms" } as React.CSSProperties}>
            From antibiotics and gastro-care to women’s health and nutrition, browse every pack in the Albert range and send one
            enquiry for everything you need.
          </p>

          <div className="hero-rise mt-9 flex flex-col items-start gap-5 sm:flex-row sm:items-center sm:gap-8" style={{ "--d": "500ms" } as React.CSSProperties}>
            <Button size="lg" href="#products" onClick={() => browseCategory("all")}>
              Browse the range
            </Button>
            <a
              href="#trust"
              className="group inline-flex items-center gap-2 text-[15px] font-semibold text-navy"
            >
              <span className="border-b border-navy/25 pb-0.5 transition-colors duration-300 group-hover:border-navy">Read the quality policy</span>
              <Icon name="arrowUpRight" size={16} className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </div>
        </div>

        {/* Composition */}
        <div className="relative mx-auto aspect-[1/1.02] w-full max-w-[560px] sm:aspect-[1/0.78] sm:max-w-[560px] lg:aspect-auto lg:h-[clamp(500px,calc(100svh-306px),700px)] lg:max-w-none">
          <div className="hero-arch absolute inset-x-[9%] bottom-0 top-0 overflow-hidden rounded-t-[999px] bg-brand">
            <FallbackImg
              srcs={[...officialFacility[0], photoCorridor]}
              alt=""
              aria-hidden="true"
              width={1000}
              height={667}
              fetchPriority="high"
              referrerPolicy="no-referrer"
              className="absolute inset-0 h-full w-full object-cover object-[40%_50%] opacity-45 mix-blend-luminosity grayscale"
            />
            <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(0,104,180,0)_30%,rgba(6,24,47,0.55)_100%)]" />
          </div>

          {shelf.map((s) => {
            const prod = getProduct(s.slug)!;
            return (
              <div key={s.slug} className={`hero-pack absolute ${s.cls}`} style={{ "--d": `${s.delay}ms` } as React.CSSProperties}>
                <button
                  type="button"
                  onClick={() => openQuickView(prod.slug)}
                  aria-label={`Quick view ${prod.name}, ${prod.generic}`}
                  className="group block w-full transition-transform duration-500 ease-[var(--ease-out-expo)] hover:-translate-y-2"
                >
                  <ProductVisual
                    product={prod}
                    eager
                    sizes="(min-width:1024px) 26vw, 50vw"
                    imgClassName="drop-shadow-[0_26px_26px_rgba(0,10,30,0.5)]"
                  />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Care-area index */}
      <nav aria-label="Care areas" className="border-t border-line bg-white">
        <ul className="mx-auto grid max-w-[1440px] grid-cols-2 lg:grid-cols-6 lg:px-10">
          {categories.map((c) => {
            const n = productsIn(c.id).length;
            return (
              <li key={c.id} className="border-b border-line lg:border-b-0 lg:border-r lg:first:border-l [&:nth-child(odd)]:border-r max-lg:[&:nth-child(odd)]:border-line lg:[&:nth-child(odd)]:border-r">
                <a
                  href="#products"
                  onClick={() => browseCategory(c.id)}
                  className="group relative flex h-full flex-col justify-between gap-6 px-5 py-5 transition-colors duration-300 hover:bg-mist/70 lg:min-h-[116px] lg:px-6"
                >
                  <span className="absolute inset-x-0 top-0 h-[2px] origin-left scale-x-0 bg-brand transition-transform duration-500 ease-[var(--ease-out-expo)] group-hover:scale-x-100" />
                  <span className="font-display text-[18px] font-medium leading-tight text-ink">{c.name}</span>
                  <span className="flex items-center justify-between text-[12.5px] text-slate">
                    {n} {n === 1 ? "product" : "products"}
                    <Icon name="arrowRight" size={15} className="text-brand transition-transform duration-300 group-hover:translate-x-1" />
                  </span>
                </a>
              </li>
            );
          })}
        </ul>
      </nav>
    </section>
  );
}
