import { useEffect, useRef } from "react";
import { getCategory, getProduct } from "../data/products";
import { useEscape } from "../hooks";
import { useStore } from "../store";
import { Icon } from "./Icon";
import { ProductVisual } from "./ui";

export function QuickView() {
  const { quickView, closeQuickView, add, items, setDrawerOpen } = useStore();
  const product = quickView ? getProduct(quickView) : undefined;
  const closeRef = useRef<HTMLButtonElement>(null);
  useEscape(!!product, closeQuickView);

  useEffect(() => {
    if (product) closeRef.current?.focus();
  }, [product]);

  if (!product) return null;
  const cat = getCategory(product.category);
  const qty = items[product.slug];

  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label={`${product.name} quick view`}>
      <div className="animate-fade-in absolute inset-0 bg-ink/65 backdrop-blur-sm" onClick={closeQuickView} />
      <div className="animate-scale-in relative grid max-h-[94svh] w-full max-w-[960px] overflow-y-auto rounded-t-[28px] bg-white shadow-[0_60px_120px_-30px_rgba(0,0,0,0.6)] sm:rounded-[28px] md:grid-cols-[1fr_1.05fr]">
        <button
          ref={closeRef}
          type="button"
          onClick={closeQuickView}
          aria-label="Close quick view"
          className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-ink shadow transition-colors hover:bg-ink hover:text-white"
        >
          <Icon name="close" size={18} />
        </button>

        <div className="relative flex min-h-[260px] items-center justify-center overflow-hidden bg-navy p-8 md:min-h-[520px]">
          <ProductVisual product={product} className="relative w-full" imgClassName="drop-shadow-[0_34px_36px_rgba(0,8,24,0.6)]" eager />
        </div>

        <div className="flex flex-col p-7 sm:p-10">
          <p className="text-[13px] font-semibold text-brand">
            {cat.name} · {product.segment}
          </p>
          <h3 className="font-display mt-3 text-[40px] font-semibold leading-none tracking-[-0.02em] text-ink">{product.name}</h3>
          <p className="mt-2 text-[16px] font-medium text-slate">{product.generic}</p>

          <dl className="mt-7 divide-y divide-line border-y border-line text-[14px]">
            <div className="flex justify-between gap-6 py-3.5">
              <dt className="text-slate">Pack</dt>
              <dd className="text-right font-semibold text-ink">{product.pack}</dd>
            </div>
            <div className="flex justify-between gap-6 py-3.5">
              <dt className="text-slate">Segment</dt>
              <dd className="text-right font-semibold text-ink">{product.segment}</dd>
            </div>
            {product.range && (
              <div className="flex justify-between gap-6 py-3.5">
                <dt className="text-slate">Listed range</dt>
                <dd className="text-right font-semibold text-ink">{product.range}</dd>
              </div>
            )}
          </dl>

          {product.summary && <p className="mt-6 text-[14.5px] leading-[1.7] text-slate">{product.summary}</p>}

          <div className="mt-auto flex flex-col gap-3 pt-8 sm:flex-row">
            <button
              type="button"
              onClick={() => add(product.slug)}
              className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-brand hover:bg-navy text-sm font-semibold text-white shadow-[0_10px_28px_-10px_rgba(0,104,180,0.8)] transition-transform duration-300 hover:-translate-y-0.5"
            >
              <Icon name="plus" size={17} strokeWidth={2} />
              {qty ? `Add another (${qty} in list)` : "Add to enquiry list"}
            </button>
            {qty ? (
              <button
                type="button"
                onClick={() => {
                  closeQuickView();
                  setDrawerOpen(true);
                }}
                className="flex h-12 items-center justify-center gap-2 rounded-full border border-navy/20 px-6 text-sm font-semibold text-navy transition-colors hover:bg-navy hover:text-white"
              >
                View list
              </button>
            ) : (
              <a
                href={product.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-12 items-center justify-center gap-2 rounded-full border border-navy/20 px-6 text-sm font-semibold text-navy transition-colors hover:bg-navy hover:text-white"
              >
                Full details <Icon name="arrowUpRight" size={16} />
              </a>
            )}
          </div>
          <p className="mt-5 text-[11.5px] leading-relaxed text-slate/70">
            Information from albertpharma.com for general reference. Consult a healthcare professional before use.
          </p>
        </div>
      </div>
    </div>
  );
}
