import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { categories, productsIn, getProduct, company } from "../data/products";
import { logoFullNavy } from "../assets";
import { useActiveSection, useScrolled } from "../hooks";
import { useStore } from "../store";
import { Icon } from "./Icon";
import { ProductVisual, cx } from "./ui";

const navItems = [
  { label: "Home", id: "top", href: "#top" },
  { label: "About Us", id: "story", href: "#story" },
  { label: "Products", id: "products", href: "#products", mega: true },
  { label: "Categories", id: "categories", href: "#categories" },
  { label: "Quality", id: "trust", href: "#trust" },
  { label: "Contact", id: "contact", href: "#contact" },
];

export const HEADER_H = 76;

export function Header() {
  const scrolled = useScrolled(30);
  const active = useActiveSection(["top", "trust", "categories", "products", "story", "contact"]);
  const { count, setDrawerOpen, setSearchOpen, openQuickView, browseCategory } = useStore();
  const [mega, setMega] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [mobileCat, setMobileCat] = useState(false);
  const closeTimer = useRef<number | undefined>(undefined);
  const headerRef = useRef<HTMLElement>(null);
  const [menuTop, setMenuTop] = useState(HEADER_H);
  const [bump, setBump] = useState(false);

  // bag badge micro-bounce when count changes
  useEffect(() => {
    if (count === 0) return;
    setBump(true);
    const t = window.setTimeout(() => setBump(false), 450);
    return () => window.clearTimeout(t);
  }, [count]);

  useEffect(() => {
    if (mobile && headerRef.current) setMenuTop(Math.round(headerRef.current.getBoundingClientRect().bottom));
    document.body.style.overflow = mobile ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobile]);

  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMega(false);
        setMobile(false);
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, [setSearchOpen]);

  const openMega = () => {
    window.clearTimeout(closeTimer.current);
    setMega(true);
  };
  const closeMega = () => {
    window.clearTimeout(closeTimer.current);
    closeTimer.current = window.setTimeout(() => setMega(false), 140);
  };

  const iconBtn = cx(
    "relative inline-flex h-11 w-11 items-center justify-center rounded-full transition-colors duration-300",
    "text-ink hover:bg-mist",
  );

  return (
    <header
      ref={headerRef}
      className={cx(
        "sticky top-0 z-40 border-b border-line bg-white/95 backdrop-blur-xl transition-shadow duration-500",
        (scrolled || mega || mobile) && "shadow-[0_14px_30px_-22px_rgba(6,24,47,0.35)]",
      )}
      onMouseLeave={closeMega}
    >
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-4 px-5 lg:px-10" style={{ height: HEADER_H }}>
        <a href="#top" aria-label="Albert Pharmaceuticals — home" className="relative block h-11 w-[150px] shrink-0 sm:w-[168px]">
          <img
            src={logoFullNavy}
            alt="Albert Pharmaceuticals"
            width={700}
            height={211}
            className="h-full w-full object-contain object-left"
          />
        </a>

        {/* Desktop nav */}
        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {navItems.map((n) => {
              const isActive = active === n.id;
              return (
                <li key={n.id} onMouseEnter={n.mega ? openMega : closeMega}>
                  {n.mega ? (
                    <button
                      type="button"
                      aria-expanded={mega}
                      aria-haspopup="true"
                      onClick={() => setMega((v) => !v)}
                      onFocus={openMega}
                      className={cx(
                        "group relative flex h-11 items-center gap-1.5 px-4 text-[14px] font-semibold tracking-[0.01em] transition-colors",
                        "text-ink/70 hover:text-ink",
                      )}
                    >
                      {n.label}
                      <Icon name="chevronDown" size={14} className={cx("transition-transform duration-300", mega && "rotate-180")} />
                      <Underline on={isActive || mega} />
                    </button>
                  ) : (
                    <a
                      href={n.href}
                      className={cx(
                        "group relative flex h-11 items-center px-4 text-[14px] font-semibold tracking-[0.01em] transition-colors",
                        "text-ink/70 hover:text-ink",
                      )}
                    >
                      {n.label}
                      <Underline on={isActive} />
                    </a>
                  )}
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSearchOpen(true)}
            aria-label="Search products"
            className={cx(
              "hidden h-11 items-center gap-3 rounded-full border px-4 text-[13px] transition-colors duration-300 xl:flex xl:w-[230px]",
              "border-line bg-mist/70 text-slate hover:border-navy/30 hover:bg-white",
            )}
          >
            <Icon name="search" size={16} />
            <span className="flex-1 text-left">Search medicines…</span>
            <kbd className={cx("rounded-md px-1.5 py-0.5 font-sans text-[10px] font-semibold", "bg-white text-slate")}>
              Ctrl K
            </kbd>
          </button>
          <button type="button" onClick={() => setSearchOpen(true)} aria-label="Search products" className={cx(iconBtn, "xl:hidden")}>
            <Icon name="search" size={21} />
          </button>
          <button type="button" onClick={() => setDrawerOpen(true)} aria-label={`Enquiry list, ${count} items`} className={iconBtn}>
            <Icon name="bag" size={21} />
            {count > 0 && (
              <span
                className={cx(
                  "absolute right-0.5 top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-teal px-1 text-[10px] font-bold text-white transition-transform duration-300",
                  bump && "scale-125",
                )}
              >
                {count}
              </span>
            )}
          </button>
          <a
            href="#contact"
            className="ml-2 hidden h-11 items-center rounded-full bg-ink px-5 text-[13px] font-semibold text-white transition-colors duration-300 hover:bg-brand md:inline-flex"
          >
            Enquire
          </a>
          <button
            type="button"
            onClick={() => setMobile((v) => !v)}
            aria-label={mobile ? "Close menu" : "Open menu"}
            aria-expanded={mobile}
            className={cx(iconBtn, "lg:hidden")}
          >
            <Icon name={mobile ? "close" : "menu"} size={23} />
          </button>
        </div>
      </div>

      {/* Mega menu */}
      {mega && (
        <div className="absolute inset-x-0 top-full hidden px-10 lg:block" onMouseEnter={openMega}>
          <div className="animate-scale-in mx-auto max-w-[1360px] origin-top overflow-hidden rounded-b-[28px] border border-t-0 border-line bg-white shadow-[0_40px_80px_-30px_rgba(6,24,47,0.45)]">
            <div className="grid grid-cols-[1fr_320px]">
              <div className="grid grid-cols-3 gap-x-8 gap-y-8 p-9">
                {categories.map((c) => (
                  <div key={c.id}>
                    <button
                      type="button"
                      onClick={() => {
                        setMega(false);
                        browseCategory(c.id);
                      }}
                      className="group mb-3 flex w-full items-center justify-between border-b border-line pb-2.5 text-left"
                    >
                      <span className="font-display text-[17px] font-semibold text-ink group-hover:text-brand">{c.name}</span>
                      <Icon name="arrowRight" size={15} className="text-brand opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:opacity-100" />
                    </button>
                    <ul className="space-y-1.5">
                      {productsIn(c.id).map((p) => (
                        <li key={p.slug}>
                          <button
                            type="button"
                            onClick={() => {
                              setMega(false);
                              openQuickView(p.slug);
                            }}
                            className="text-[13.5px] text-slate transition-colors hover:text-brand"
                          >
                            {p.name}
                            <span className="ml-1.5 text-[11.5px] text-slate/60">{p.generic.split(/[\s,]/)[0]}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
              <MegaFeature />
            </div>
            <div className="flex items-center justify-between border-t border-line bg-mist/70 px-9 py-3.5 text-[13px] text-slate">
              <span>25 products across 6 care areas · listed from albertpharma.com</span>
              <button
                type="button"
                onClick={() => {
                  setMega(false);
                  browseCategory("all");
                }}
                className="group inline-flex items-center gap-2 font-semibold text-brand"
              >
                Browse the full range
                <Icon name="arrowRight" size={15} className="transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile menu */}
      {mobile && createPortal(
        <div
          className="animate-fade-in fixed inset-x-0 bottom-0 z-30 overflow-y-auto bg-white lg:hidden"
          style={{ top: menuTop }}
        >
          <nav aria-label="Mobile" className="flex min-h-full flex-col px-6 pb-10 pt-4">
            <ul className="divide-y divide-line">
              {navItems.map((n, i) => (
                <li key={n.id} className="animate-slide-up" style={{ animationDelay: `${i * 45}ms` }}>
                  {n.mega ? (
                    <>
                      <button
                        type="button"
                        onClick={() => setMobileCat((v) => !v)}
                        aria-expanded={mobileCat}
                        className="flex w-full items-center justify-between py-4 font-display text-[28px] font-medium text-ink"
                      >
                        {n.label}
                        <Icon name="chevronDown" size={22} className={cx("transition-transform duration-300", mobileCat && "rotate-180")} />
                      </button>
                      {mobileCat && (
                        <ul className="animate-fade-in grid grid-cols-1 gap-1 pb-4">
                          {categories.map((c) => (
                            <li key={c.id}>
                              <button
                                type="button"
                                onClick={() => {
                                  setMobile(false);
                                  setMobileCat(false);
                                  browseCategory(c.id);
                                }}
                                className="flex w-full items-center justify-between rounded-xl bg-mist px-4 py-3 text-left"
                              >
                                <span>
                                  <span className="block text-[15px] font-semibold text-ink">{c.name}</span>
                                  <span className="block text-[12px] text-slate">{c.short}</span>
                                </span>
                                <span className="rounded-full bg-white px-2.5 py-1 text-[11px] font-bold text-brand">
                                  {productsIn(c.id).length}
                                </span>
                              </button>
                            </li>
                          ))}
                        </ul>
                      )}
                    </>
                  ) : (
                    <a
                      href={n.href}
                      onClick={() => setMobile(false)}
                      className="flex items-center justify-between py-4 font-display text-[28px] font-medium text-ink"
                    >
                      {n.label}
                      <Icon name="arrowUpRight" size={20} className="text-brand" />
                    </a>
                  )}
                </li>
              ))}
            </ul>
            <div className="mt-auto space-y-3 pt-10">
              <button
                type="button"
                onClick={() => {
                  setMobile(false);
                  setSearchOpen(true);
                }}
                className="flex h-14 w-full items-center gap-3 rounded-full border border-line bg-mist px-5 text-slate"
              >
                <Icon name="search" size={18} /> Search medicines…
              </button>
              <a href={company.phoneHref} className="flex h-14 w-full items-center justify-center gap-2.5 rounded-full bg-ink font-semibold text-white">
                <Icon name="phone" size={17} /> {company.phone}
              </a>
            </div>
          </nav>
        </div>,
        document.body,
      )}
    </header>
  );
}

function Underline({ on }: { on: boolean }) {
  return (
    <span
      className={cx(
        "absolute inset-x-4 bottom-1.5 h-[2px] origin-left rounded-full transition-transform duration-500 ease-[var(--ease-out-expo)]",
        "bg-brand",
        on ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100",
      )}
    />
  );
}

function MegaFeature() {
  const { openQuickView } = useStore();
  const p = getProduct("esobert")!;
  return (
    <div className="relative flex flex-col justify-between overflow-hidden bg-navy p-8 text-white">
      <div className="relative">
        <p className="text-[12px] font-semibold text-aqua">Featured pack</p>
        <p className="mt-2 font-display text-[26px] font-semibold leading-tight">{p.name}</p>
        <p className="text-[13px] text-white/65">
          {p.generic} · {p.segment}
        </p>
      </div>
      <ProductVisual product={p} className="relative my-4" imgClassName="drop-shadow-[0_22px_30px_rgba(0,0,0,0.45)]" />
      <button
        type="button"
        onClick={() => openQuickView(p.slug)}
        className="group relative inline-flex w-fit items-center gap-2 text-[13px] font-semibold text-white"
      >
        Quick view <Icon name="arrowRight" size={15} className="transition-transform group-hover:translate-x-1" />
      </button>
    </div>
  );
}
