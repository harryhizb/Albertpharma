import { useStore } from "../store";
import { Icon } from "./Icon";

export function Toast() {
  const { toast } = useStore();
  if (!toast) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-5 z-[100] flex justify-center px-4" role="status" aria-live="polite">
      <div key={toast.id} className="animate-slide-up pointer-events-auto flex items-center gap-4 rounded-full bg-ink py-2.5 pl-3 pr-3 text-white shadow-[0_24px_50px_-16px_rgba(0,0,0,0.6)]">
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-teal">
          <Icon name="check" size={16} strokeWidth={2.4} />
        </span>
        <p className="text-[13.5px] font-medium">{toast.message}</p>
        {toast.action && (
          <button type="button" onClick={toast.action.run} className="rounded-full bg-white/12 px-4 py-2 text-[12.5px] font-semibold transition-colors hover:bg-white hover:text-ink">
            {toast.action.label}
          </button>
        )}
      </div>
    </div>
  );
}
