import { officialFeatured, brandMark } from "../assets";
import { FallbackImg } from "./FallbackImg";
import { Reveal } from "./ui";

/** Visual band: the "Our Featured Brands" banners, loaded from the live albertpharma.com carousel. */
export function FeaturedBrands() {
  return (
    <section id="brands" aria-labelledby="brands-title" className="relative bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-[1440px] px-5 lg:px-10">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <h2 id="brands-title" className="font-display text-balance text-[clamp(32px,3.8vw,52px)] font-medium leading-[1.04] tracking-[-0.02em] text-ink">
              Our featured brands
            </h2>
          </Reveal>
          <Reveal delay={100}>
            <p className="max-w-[400px] text-[15.5px] leading-[1.7] text-slate">
              The Albert brands as they appear on albertpharma.com, shown here straight from the official site.
            </p>
          </Reveal>
        </div>

        <ul className="no-scrollbar -mx-5 mt-12 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-2 lg:mx-0 lg:grid lg:grid-cols-5 lg:gap-5 lg:overflow-visible lg:px-0">
          {officialFeatured.map((src, i) => (
            <Reveal as="li" key={src} delay={i * 70} className="w-[72%] shrink-0 snap-start sm:w-[44%] lg:w-auto">
              <div className="group flex aspect-[4/5] items-center justify-center overflow-hidden rounded-[24px] border border-line bg-mist p-6 transition-[transform,box-shadow] duration-500 ease-[var(--ease-out-expo)] hover:-translate-y-1 hover:shadow-[0_28px_44px_-30px_rgba(6,24,47,0.45)]">
                <FallbackImg
                  srcs={[src]}
                  alt={`Albert featured brand ${i + 1}`}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-contain transition-transform duration-700 ease-[var(--ease-out-expo)] group-hover:scale-[1.04]"
                  fallback={<img src={brandMark} alt="" className="h-14 w-14 opacity-30" />}
                />
              </div>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
