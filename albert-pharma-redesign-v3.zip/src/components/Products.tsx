import { useMemo, useState } from "react";
import { categories, featuredOrder, getCategory, products, type Product } from "../data/products";
import { useStore } from "../store";
import { ProductVisual, Reveal, Button, cx } from "./ui";
import { Icon } from "./Icon";

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const { add, openQuickView, items } = useStore();
  const inList = items[product.slug];

  return (
    <Reveal delay={(index % 4) * 70}>
      <article className="group flex h-full flex-col overflow-hidden rounded-[24px] border border-line bg-white transition-[transform,box-shadow,border-color] duration-500 ease-[var(--ease-out-expo)] hover:-translate-y-1.5 hover:border-transparent hover:shadow-[0_36px_56px_-30px_rgba(6,24,47,0.4)]">
        <div className="relative">
          <button
            type="button"
            onClick={() => openQuickView(product.slug)}
            aria-label={`Quick view ${product.name}`}
            className="relative block aspect-[5/4] w-full overflow-hidden bg-[radial-gradient(ellipse_at_50%_35%,#ffffff_0%,#eef4f8_60%,#e2ecf3_100%)]"
          >
            <ProductVisual
              product={product}
              className="absolute inset-0 p-[9%] transition-transform duration-[900ms] ease-[var(--ease-out-expo)] group-hover:scale-[1.07]"
              imgClassName="drop-shadow-[0_18px_20px_rgba(6,24,47,0.18)]"
              sizes="(min-width:1024px) 22vw, (min-width:640px) 45vw, 90vw"
            />
          </button>
          <span className="pointer-events-none absolute left-3.5 top-3.5 rounded-full bg-white px-3 py-1 text-[12px] font-semibold text-navy shadow-[0_1px_0_rgba(6,24,47,0.06)]">
            {product.segment}
          </span>
          <button
            type="button"
            onClick={() => openQuickView(product.slug)}
            className="absolute bottom-3.5 right-3.5 flex h-10 items-center gap-2 rounded-full bg-ink px-4 text-[12px] font-semibold text-white shadow-lg transition-all duration-500 sm:translate-y-2 sm:opacity-0 sm:group-hover:translate-y-0 sm:group-hover:opacity-100 sm:focus-visible:translate-y-0 sm:focus-visible:opacity-100"
          >
            <Icon name="eye" size={15} /> Quick view
          </button>
        </div>

        <div className="flex flex-1 flex-col p-5 sm:p-6">
          <h3 className="font-display text-[26px] font-semibold leading-tight tracking-[-0.01em] text-ink">{product.name}</h3>
          <p className="mt-1 text-[14px] font-medium text-slate">{product.generic}</p>
          <p className="mt-0.5 text-[13px] text-slate/70">{product.pack}</p>

          <div className="mt-auto flex items-center gap-2 pt-6">
            <button
              type="button"
              onClick={() => add(product.slug)}
              className={cx(
                "flex h-11 flex-1 items-center justify-center gap-2 rounded-full text-[13px] font-semibold transition-all duration-300",
                inList ? "bg-teal/10 text-[#00807f]" : "bg-mist text-navy hover:bg-navy hover:text-white",
              )}
            >
              <Icon name={inList ? "check" : "plus"} size={16} strokeWidth={2} />
              {inList ? `In list (${inList})` : "Add to enquiry"}
            </button>
            <a
              href={product.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`${product.name} on albertpharma.com`}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-navy transition-colors duration-300 hover:border-navy hover:bg-navy hover:text-white"
            >
              <Icon name="arrowUpRight" size={17} />
            </a>
          </div>
        </div>
      </article>
    </Reveal>
  );
}

const INITIAL = 8;

export function Products() {
  const { filter, setFilter } = useStore();
  const [expanded, setExpanded] = useState(false);

  const list = useMemo(() => {
    if (filter !== "all") return products.filter((p) => p.category === filter);
    const order = (s: string) => {
      const i = featuredOrder.indexOf(s);
      return i === -1 ? 999 : i;
    };
    return [...products].sort((a, b) => order(a.slug) - order(b.slug));
  }, [filter]);

  const visible = filter === "all" && !expanded ? list.slice(0, INITIAL) : list;
  const active = filter === "all" ? null : getCategory(filter);

  return (
    <section id="products" className="relative bg-mist py-24 sm:py-32">
      <div className="mx-auto max-w-[1440px] px-5 lg:px-10">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <Reveal delay={80}>
              <h2 className="font-display text-balance text-[clamp(32px,3.8vw,52px)] font-medium leading-[1.04] tracking-[-0.02em] text-ink">
                Browse the full range
              </h2>
            </Reveal>
          </div>
          <Reveal delay={140}>
            <p className="max-w-[420px] text-[15.5px] leading-[1.7] text-slate">
              {active
                ? active.blurb
                : "Every product below is listed on albertpharma.com. Collect what you need in your enquiry list and send it in one go."}
            </p>
          </Reveal>
        </div>

        {/* Filters */}
        <Reveal delay={120} className="-mx-5 mt-10 lg:mx-0">
          <div role="tablist" aria-label="Filter products by care area" className="no-scrollbar flex gap-2.5 overflow-x-auto px-5 pb-2 lg:flex-wrap lg:px-0">
            {[{ id: "all" as const, name: "All products", n: products.length }, ...categories.map((c) => ({ id: c.id, name: c.name, n: products.filter((p) => p.category === c.id).length }))].map((f) => {
              const on = filter === f.id;
              return (
                <button
                  key={f.id}
                  type="button"
                  role="tab"
                  aria-selected={on}
                  onClick={() => {
                    setFilter(f.id);
                    setExpanded(false);
                  }}
                  className={cx(
                    "flex h-11 shrink-0 items-center gap-2.5 rounded-full border px-5 text-[13.5px] font-semibold transition-all duration-300",
                    on ? "border-navy bg-navy text-white" : "border-line bg-white text-slate hover:border-navy/40 hover:text-navy",
                  )}
                >
                  {f.name}
                  <span className={cx("rounded-full px-2 py-0.5 text-[11px] font-bold", on ? "bg-white/15 text-white" : "bg-mist text-slate")}>{f.n}</span>
                </button>
              );
            })}
          </div>
        </Reveal>

        <div key={filter} className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
          {visible.map((p, i) => (
            <ProductCard key={p.slug} product={p} index={i} />
          ))}
        </div>

        {filter === "all" && !expanded && (
          <div className="mt-14 flex justify-center">
            <Button variant="dark" size="lg" icon="plus" onClick={() => setExpanded(true)}>
              Show all {products.length} products
            </Button>
          </div>
        )}

        <p className="mx-auto mt-14 max-w-[720px] text-center text-[12px] leading-relaxed text-slate/70">
          Product information is sourced from albertpharma.com and is for general reference only. Please consult a healthcare
          professional before using any medicine. Consumer Healthcare pack artwork is shown as a placeholder until photography is supplied.
        </p>
      </div>
    </section>
  );
}
