import { categories, getCategory, productsIn, getProduct, type CategoryId } from "../data/products";
import { useStore } from "../store";
import { ProductVisual, Reveal, cx } from "./ui";
import { Icon } from "./Icon";

interface PackSpot {
  slug: string;
  pos: string; // tailwind positioning + width classes
  rot?: string;
  z?: string;
}

interface Tile {
  id: CategoryId;
  grid: string;
  tone: string;
  dark: boolean;
  packs: PackSpot[];
}

const tiles: Tile[] = [
  {
    id: "anti-infectives",
    grid: "lg:col-span-5 lg:row-span-2 min-h-[420px] lg:min-h-0",
    tone: "bg-navy",
    dark: true,
    packs: [
      { slug: "linezert", pos: "right-[-8%] bottom-[40%] w-[60%]", rot: "rotate-[6deg]", z: "z-0" },
      { slug: "cixalt", pos: "left-[24%] bottom-[16%] w-[54%]", rot: "-rotate-[5deg]", z: "z-10" },
      { slug: "alzacin", pos: "right-[-9%] bottom-[-5%] w-[60%]", rot: "rotate-[3deg]", z: "z-20" },
    ],
  },
  {
    id: "gastro",
    grid: "lg:col-span-4 min-h-[260px] lg:min-h-0",
    tone: "bg-fog",
    dark: false,
    packs: [
      { slug: "exocid", pos: "right-[22%] bottom-[-14%] w-[52%]", rot: "-rotate-[4deg]", z: "z-0" },
      { slug: "esobert", pos: "right-[-8%] bottom-[-10%] w-[58%]", rot: "rotate-[4deg]", z: "z-10" },
    ],
  },
  {
    id: "pain",
    grid: "lg:col-span-3 min-h-[260px] lg:min-h-0",
    tone: "bg-white border border-line",
    dark: false,
    packs: [{ slug: "etogesic", pos: "right-[-14%] bottom-[-6%] w-[86%]", rot: "rotate-[3deg]" }],
  },
  {
    id: "neuro",
    grid: "lg:col-span-3 min-h-[260px] lg:min-h-0",
    tone: "bg-white border border-line",
    dark: false,
    packs: [{ slug: "baliptic", pos: "right-[-14%] bottom-[-6%] w-[86%]", rot: "-rotate-[3deg]" }],
  },
  {
    id: "cardio",
    grid: "lg:col-span-4 min-h-[260px] lg:min-h-0",
    tone: "bg-fog",
    dark: false,
    packs: [
      { slug: "amsapin", pos: "right-[26%] bottom-[-14%] w-[50%]", rot: "-rotate-[5deg]", z: "z-0" },
      { slug: "altelu", pos: "right-[-9%] bottom-[-10%] w-[56%]", rot: "rotate-[4deg]", z: "z-10" },
    ],
  },
];

export function Categories() {
  const { browseCategory } = useStore();
  const consumer = getCategory("consumer");
  const consumerProducts = productsIn("consumer");

  return (
    <section id="categories" className="relative bg-mist py-24 sm:py-32">
      <div className="mx-auto max-w-[1440px] px-5 lg:px-10">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div>
            <Reveal delay={80}>
              <h2 className="font-display max-w-[640px] text-balance text-[clamp(32px,3.8vw,52px)] font-medium leading-[1.04] tracking-[-0.02em] text-ink">
                Find a medicine by care area.
              </h2>
            </Reveal>
          </div>
          <Reveal delay={140}>
            <p className="max-w-[380px] text-[15.5px] leading-[1.7] text-slate">
              Every pack in the range, grouped by therapeutic segment. Choose a care area to see what sits inside it.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-4 lg:auto-rows-[290px] lg:grid-cols-12 lg:gap-5">
          {tiles.map((t, i) => {
            const c = getCategory(t.id);
            const n = productsIn(t.id).length;
            return (
              <Reveal key={t.id} delay={(i % 3) * 90} className={cx("relative", t.grid)}>
                <button
                  type="button"
                  onClick={() => browseCategory(t.id)}
                  aria-label={`Browse ${c.name} — ${n} products`}
                  className={cx(
                    "group relative isolate flex h-full min-h-[inherit] w-full flex-col justify-between overflow-hidden rounded-[24px] p-7 text-left sm:p-8",
                    "transition-[transform,box-shadow] duration-700 ease-[var(--ease-out-expo)] hover:-translate-y-1",
                    "hover:shadow-[0_28px_44px_-30px_rgba(6,24,47,0.45)]",
                    t.tone,
                    t.dark ? "text-white" : "text-ink",
                  )}
                >

                  <div className="relative z-30">
                    <p className={cx("text-[13px] font-medium", t.dark ? "text-white/65" : "text-slate")}>{c.short}</p>
                    <h3
                      className={cx(
                        "font-display mt-3 font-medium leading-[1.04] tracking-[-0.015em]",
                        t.id === "anti-infectives" ? "max-w-[300px] text-[clamp(32px,3.2vw,46px)]" : "max-w-[210px] text-[clamp(26px,2.4vw,34px)]",
                      )}
                    >
                      {c.name}
                    </h3>
                  </div>

                  <div className="relative z-30 flex items-center gap-3">
                    <span
                      className={cx(
                        "flex h-11 w-11 items-center justify-center rounded-full transition-all duration-500 group-hover:translate-x-1",
                        t.dark ? "bg-white text-navy" : "bg-ink text-white",
                      )}
                    >
                      <Icon name="arrowRight" size={18} />
                    </span>
                    <span className={cx("text-[13px] font-semibold", t.dark ? "text-white/80" : "text-ink/70")}>
                      {n} {n === 1 ? "product" : "products"}
                    </span>
                  </div>

                  {/* packs */}
                  {t.packs.map((p, j) => {
                    const prod = getProduct(p.slug)!;
                    // small screens: one front pack per tile, so artwork never runs under the copy
                    const mobile = j === t.packs.length - 1 ? "max-lg:left-auto max-lg:right-[-6%] max-lg:bottom-[-8%] max-lg:w-[46%]" : "max-lg:hidden";
                    return (
                      <div
                        key={p.slug}
                        className={cx(
                          "pointer-events-none absolute transition-transform duration-[900ms] ease-[var(--ease-out-expo)] group-hover:-translate-y-3 group-hover:scale-[1.04]",
                          p.pos,
                          p.z,
                          mobile,
                        )}
                      >
                        <div className={p.rot}>
                          <ProductVisual product={prod} sizes="(min-width:1024px) 30vw, 70vw" imgClassName="drop-shadow-[0_24px_28px_rgba(6,24,47,0.35)]" />
                        </div>
                      </div>
                    );
                  })}
                </button>
              </Reveal>
            );
          })}

          {/* Consumer healthcare — full-width band (no pack artwork available yet) */}
          <Reveal delay={120} className="lg:col-span-12">
            <button
              type="button"
              onClick={() => browseCategory("consumer")}
              aria-label={`Browse ${consumer.name} — ${consumerProducts.length} products`}
              className="group relative isolate flex w-full flex-col gap-8 overflow-hidden rounded-[24px] bg-navy p-7 text-left text-white transition-[transform,box-shadow] duration-700 ease-[var(--ease-out-expo)] hover:-translate-y-1 hover:shadow-[0_40px_60px_-32px_rgba(6,24,47,0.6)] sm:p-9 lg:flex-row lg:items-center lg:justify-between"
            >
              <div>
                <p className="text-[13px] font-medium text-white/65">{consumer.short}</p>
                <h3 className="font-display mt-3 text-[clamp(28px,3vw,42px)] font-medium leading-tight tracking-[-0.015em]">{consumer.name}</h3>
                <div className="mt-6 flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-white text-navy transition-transform duration-500 group-hover:translate-x-1">
                    <Icon name="arrowRight" size={18} />
                  </span>
                  <span className="text-[13px] font-semibold text-white/80">{consumerProducts.length} products</span>
                </div>
              </div>
              <ul className="flex flex-wrap gap-2.5 lg:max-w-[640px] lg:justify-end">
                {consumerProducts.map((p) => (
                  <li
                    key={p.slug}
                    className="rounded-full border border-white/15 bg-white/[0.06] px-4 py-2 text-[13px] font-semibold text-white/90 transition-colors duration-300 group-hover:border-white/30"
                  >
                    {p.name}
                    <span className="ml-2 text-[11px] font-medium text-white/50">{p.segment}</span>
                  </li>
                ))}
              </ul>
            </button>
          </Reveal>
        </div>
        <span className="sr-only">{categories.length} care areas</span>
      </div>
    </section>
  );
}
