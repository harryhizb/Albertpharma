import { useEffect, useMemo, useRef, useState } from "react";
import { categories, getCategory, products } from "../data/products";
import { useEscape } from "../hooks";
import { useStore } from "../store";
import { Icon } from "./Icon";
import { ProductVisual } from "./ui";

const popular = ["Omeprazole", "Azithromycin", "Antibiotic", "Women's Health", "Etoricoxib"];

export function SearchOverlay() {
  const { searchOpen, setSearchOpen, openQuickView, browseCategory } = useStore();
  const [q, setQ] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const close = () => {
    setSearchOpen(false);
  };
  useEscape(searchOpen, close);

  useEffect(() => {
    if (searchOpen) {
      setQ("");
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [searchOpen]);

  const results = useMemo(() => {
    const term = q.trim().toLowerCase().replace(/[’']/g, "");
    if (!term) return [];
    return products.filter((p) => {
      const hay = `${p.name} ${p.generic} ${p.segment} ${getCategory(p.category).name} ${p.summary ?? ""}`
        .toLowerCase()
        .replace(/[’']/g, "");
      return term.split(/\s+/).every((t) => hay.includes(t));
    });
  }, [q]);

  if (!searchOpen) return null;

  const pick = (slug: string) => {
    close();
    openQuickView(slug);
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-start justify-center p-4 pt-[8svh] sm:p-6 sm:pt-[10svh]" role="dialog" aria-modal="true" aria-label="Search products">
      <div className="animate-fade-in absolute inset-0 bg-ink/70 backdrop-blur-md" onClick={close} />
      <div className="animate-scale-in relative w-full max-w-[720px] overflow-hidden rounded-[26px] bg-white shadow-[0_60px_120px_-30px_rgba(0,0,0,0.7)]">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (results[0]) pick(results[0].slug);
          }}
          className="flex items-center gap-3 border-b border-line px-5 sm:px-7"
        >
          <Icon name="search" size={22} className="shrink-0 text-brand" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by brand, generic name or segment…"
            aria-label="Search products"
            className="h-[72px] w-full bg-transparent text-[17px] text-ink outline-none placeholder:text-slate/50"
          />
          <button type="button" onClick={close} aria-label="Close search" className="flex h-9 shrink-0 items-center rounded-full bg-mist px-3 text-[11px] font-bold tracking-wider text-slate transition-colors hover:bg-navy hover:text-white">
            ESC
          </button>
        </form>

        <div className="max-h-[56svh] overflow-y-auto p-3 sm:p-4">
          {!q.trim() && (
            <div className="p-3 sm:p-4">
              <p className="text-[13px] font-semibold text-slate">Popular searches</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {popular.map((s) => (
                  <button key={s} type="button" onClick={() => setQ(s)} className="rounded-full border border-line px-4 py-2 text-[13px] font-semibold text-navy transition-colors hover:border-navy hover:bg-navy hover:text-white">
                    {s}
                  </button>
                ))}
              </div>
              <p className="mt-8 text-[13px] font-semibold text-slate">Browse care areas</p>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {categories.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => {
                      close();
                      browseCategory(c.id);
                    }}
                    className="group flex items-center justify-between rounded-2xl bg-mist px-4 py-3.5 text-left transition-colors hover:bg-navy"
                  >
                    <span>
                      <span className="block text-[14px] font-semibold text-ink group-hover:text-white">{c.name}</span>
                      <span className="block text-[12px] text-slate group-hover:text-white/60">{c.short}</span>
                    </span>
                    <Icon name="arrowRight" size={16} className="text-brand transition-transform group-hover:translate-x-1 group-hover:text-aqua" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {q.trim() && results.length > 0 && (
            <ul>
              <li className="px-3 pb-2 pt-1 text-[13px] font-semibold text-slate">
                {results.length} {results.length === 1 ? "result" : "results"}
              </li>
              {results.map((p) => (
                <li key={p.slug}>
                  <button type="button" onClick={() => pick(p.slug)} className="group flex w-full items-center gap-4 rounded-2xl p-3 text-left transition-colors hover:bg-mist">
                    <span className="h-16 w-20 shrink-0 overflow-hidden rounded-xl bg-[radial-gradient(ellipse_at_50%_35%,#fff,#e6eef4)]">
                      <ProductVisual product={p} className="h-full w-full p-1.5" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block font-display text-[19px] font-semibold leading-tight text-ink">{p.name}</span>
                      <span className="block truncate text-[13px] text-slate">
                        {p.generic} · {p.pack}
                      </span>
                    </span>
                    <span className="hidden rounded-full bg-white px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-brand ring-1 ring-line sm:block">{p.segment}</span>
                    <Icon name="arrowRight" size={16} className="text-slate transition-transform group-hover:translate-x-1 group-hover:text-brand" />
                  </button>
                </li>
              ))}
            </ul>
          )}

          {q.trim() && results.length === 0 && (
            <div className="px-6 py-14 text-center">
              <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-mist text-brand">
                <Icon name="search" size={24} />
              </span>
              <p className="font-display mt-5 text-[24px] font-medium text-ink">No match for “{q.trim()}”</p>
              <p className="mx-auto mt-2 max-w-[360px] text-[14px] leading-relaxed text-slate">
                Try a generic name such as <button type="button" className="font-semibold text-brand underline-offset-2 hover:underline" onClick={() => setQ("Omeprazole")}>Omeprazole</button>, or browse a care area. Can’t find what you need? Our team can help.
              </p>
              <a href="#contact" onClick={close} className="mt-6 inline-flex h-11 items-center gap-2 rounded-full bg-ink px-6 text-[13px] font-semibold text-white">
                Contact the team <Icon name="arrowRight" size={15} />
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
