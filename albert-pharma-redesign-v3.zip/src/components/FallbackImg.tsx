import { useState, type ImgHTMLAttributes } from "react";

/**
 * <img> that walks a list of sources: the first that loads wins. If every source fails it renders nothing
 * (or the optional `onExhausted` fallback), so a blocked remote image never leaves a broken-image icon.
 */
export function FallbackImg({
  srcs,
  alt,
  fallback,
  ...rest
}: { srcs: string[]; alt: string; fallback?: React.ReactNode } & Omit<ImgHTMLAttributes<HTMLImageElement>, "src" | "alt">) {
  const [i, setI] = useState(0);
  if (i >= srcs.length) return <>{fallback ?? null}</>;
  return <img {...rest} src={srcs[i]} alt={alt} onError={() => setI((n) => n + 1)} />;
}
