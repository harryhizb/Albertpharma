import { getProduct } from "../data/products";
import { useStore } from "../store";
import { Button, ProductVisual, Reveal } from "./ui";

const packs = ["esobert", "exocid", "fobert", "mesodim"] as const;

/** Collection spotlight — flat brand-blue panel, four packs in a tidy 2×2 (no tilt, no floating). */
export function Campaign() {
  const { browseCategory, openQuickView } = useStore();
  return (
    <section id="campaign" className="overflow-hidden bg-brand text-white">
      <Reveal className="mx-auto max-w-[1440px]">
        <div className="grid items-center gap-10 px-5 py-20 sm:py-24 lg:grid-cols-[0.9fr_1.1fr] lg:gap-6 lg:px-10 lg:py-0">
          <div className="max-w-[520px] lg:py-24">
            <h2 className="font-display text-[clamp(34px,4.4vw,60px)] font-medium leading-[1.02] tracking-[-0.025em]">
              The Gastro-Care collection
            </h2>
            <p className="mt-6 text-[16.5px] leading-[1.7] text-white/80">
              Esobert, eXocid, Fobert and Mesodim SR: four formulations covering ulcer, reflux and spasm care, side by side in one
              range.
            </p>
            <div className="mt-8">
              <Button variant="light" size="lg" onClick={() => browseCategory("gastro")}>
                Explore the collection
              </Button>
            </div>
          </div>

          <ul className="grid grid-cols-2 gap-x-4 gap-y-2 sm:gap-x-8 lg:py-14">
            {packs.map((slug, i) => {
              const prod = getProduct(slug)!;
              return (
                <li key={slug} className={i % 2 === 1 ? "lg:translate-y-10" : undefined}>
                  <button
                    type="button"
                    onClick={() => openQuickView(prod.slug)}
                    aria-label={`Quick view ${prod.name}, ${prod.generic}`}
                    className="group block w-full text-center"
                  >
                    <span className="block transition-transform duration-500 ease-[var(--ease-out-expo)] group-hover:-translate-y-2">
                      <ProductVisual product={prod} sizes="(min-width:1024px) 22vw, 45vw" imgClassName="drop-shadow-[0_24px_22px_rgba(0,20,50,0.4)]" />
                    </span>
                    <span className="mt-1 block text-[14px] font-semibold">{prod.name}</span>
                    <span className="block text-[12.5px] text-white/70">{prod.generic}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </Reveal>
    </section>
  );
}
