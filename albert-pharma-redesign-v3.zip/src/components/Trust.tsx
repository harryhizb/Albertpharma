import { company } from "../data/products";
import { useCountUp } from "../hooks";
import { Reveal } from "./ui";
import { Icon, type IconName } from "./Icon";

const pillars: { icon: IconName; title: string; body: string }[] = [
  {
    icon: "shield",
    title: "Quality system, in writing",
    body: "Operations run to international QMS standards such as ISO 9001:2015, as set out in our published Quality Policy.",
  },
  {
    icon: "factory",
    title: "Our own plant & head office",
    body: "Pharmaceuticals manufactured and managed by Albert Pharma (Pvt) Ltd — both locations are open on the map below.",
  },
  {
    icon: "label",
    title: "Transparent packs",
    body: "Brand, generic name, strength and pack size are printed clearly on every carton in the range.",
  },
  {
    icon: "heart",
    title: "Reliable, by value",
    body: "“We do what we say, we fulfil expectations and keep promises.” It is one of our six core values.",
  },
];

function Stat({ value, suffix = "", label }: { value: number; suffix?: string; label: string }) {
  const { ref, value: v } = useCountUp(value);
  return (
    <div className="px-2 text-center sm:px-6">
      <p className="font-display text-[40px] font-medium leading-none tracking-tight text-navy sm:text-[56px]">
        <span ref={ref}>{v}</span>
        {suffix}
      </p>
      <p className="mt-3 text-[13px] font-medium leading-snug text-slate">{label}</p>
    </div>
  );
}

export function Trust() {
  return (
    <section id="trust" className="relative border-t border-line bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-[1440px] px-5 lg:px-10">
        <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
          <div>
            <Reveal delay={80}>
              <h2 className="font-display text-balance text-[clamp(32px,3.8vw,52px)] font-medium leading-[1.04] tracking-[-0.02em] text-ink">
                Quality isn’t a claim.
                <br />
                It’s a policy.
              </h2>
            </Reveal>
            <Reveal delay={160}>
              <p className="mt-7 max-w-[470px] text-[17px] leading-[1.75] text-slate">
                Albert Pharma develops long-term relationships with its customers and is committed to manufacturing the best
                quality pharmaceutical products, meeting their specified requirements.
              </p>
            </Reveal>
            <Reveal delay={220}>
              <a
                href={`${company.site}/about-us/`}
                target="_blank"
                rel="noopener noreferrer"
                className="group mt-8 inline-flex items-center gap-2 text-[14px] font-semibold text-brand"
              >
                <span className="border-b border-brand/30 pb-0.5 transition-colors group-hover:border-brand">Read the Quality Policy</span>
                <Icon name="arrowUpRight" size={16} className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
              </a>
            </Reveal>
          </div>

          <div className="grid gap-px overflow-hidden rounded-[28px] border border-line bg-line sm:grid-cols-2">
            {pillars.map((p, i) => (
              <Reveal key={p.title} delay={i * 90} className="group bg-white p-7 transition-colors duration-500 hover:bg-mist/70 sm:p-9">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand text-white transition-transform duration-500 group-hover:-translate-y-1 group-hover:rotate-[-4deg]">
                  <Icon name={p.icon} size={22} />
                </span>
                <h3 className="font-display mt-6 text-[22px] font-semibold leading-tight text-ink">{p.title}</h3>
                <p className="mt-3 text-[14.5px] leading-[1.7] text-slate">{p.body}</p>
              </Reveal>
            ))}
          </div>
        </div>

        {/* Verified-by-source figures */}
        <Reveal className="mt-20 rounded-[28px] bg-mist px-4 py-9 sm:py-12">
          <div className="grid grid-cols-2 gap-y-10 divide-line sm:grid-cols-4 sm:divide-x">
            <Stat value={25} label="Products in the range" />
            <Stat value={6} label="Care areas covered" />
            <Stat value={6} label="Core values we live by" />
            <Stat value={2015} label="ISO 9001 QMS edition" />
          </div>
          <p className="mt-9 text-center text-[11.5px] tracking-wide text-slate/70">
            Figures counted from the current albertpharma.com catalogue and Quality Policy.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
