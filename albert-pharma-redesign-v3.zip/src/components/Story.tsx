import { useState } from "react";
import { company } from "../data/products";
import {
  hexPattern,
  officialFacility,
  officialValueIcon,
  photoBuilding,
  photoCorridor,
  valueIcon1,
  valueIcon2,
  valueIcon3,
  valueIcon4,
  valueIcon5,
  valueIcon6,
} from "../assets";
import { Button, Reveal, cx } from "./ui";
import { FallbackImg } from "./FallbackImg";
import { Icon } from "./Icon";

const tabs = [
  {
    id: "mission",
    label: "Mission",
    text: "We are committed to serve the community by continuously investing in quality of life and maintaining the quality standards of our healthcare facility.",
  },
  {
    id: "vision",
    label: "Vision",
    text: "To ensure patients’ wellbeing with consistent growth in healthcare, and to become a leading multinational converging all international quality standards in the pharmaceutical industry.",
  },
  {
    id: "quality",
    label: "Quality policy",
    text: "Maintain and run operations as per international QMS standards such as ISO 9001:2015, and continually improve the effectiveness of the Quality Management System.",
  },
];

export function Story() {
  const [tab, setTab] = useState(tabs[0].id);
  const current = tabs.find((t) => t.id === tab)!;

  return (
    <>
    <section id="story" className="relative overflow-hidden bg-white py-24 sm:py-32">
      <div className="mx-auto grid max-w-[1440px] items-center gap-16 px-5 lg:grid-cols-[1fr_1fr] lg:gap-24 lg:px-10">
        {/* Visual composition — real Albert facility photography */}
        <Reveal className="relative mx-auto w-full max-w-[640px] pb-24 sm:pb-28">
          <div className="relative aspect-[4/4.6] w-[78%] overflow-hidden rounded-[32px] shadow-[0_40px_70px_-36px_rgba(6,24,47,0.6)]">
            <FallbackImg
              srcs={[...officialFacility[1], photoCorridor]}
              alt="Clean, brightly lit production corridor at an Albert Pharma facility"
              width={1000}
              height={667}
              loading="lazy"
              className="h-full w-full object-cover object-[58%_50%] transition-transform duration-[1400ms] ease-[var(--ease-out-expo)] hover:scale-105"
            />
            <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,transparent_55%,rgba(6,24,47,0.5))]" />
            <p className="absolute bottom-5 left-5 text-[13px] font-semibold text-white">Our facility</p>
          </div>

          <div className="absolute bottom-0 right-0 aspect-square w-[54%] overflow-hidden rounded-[28px] border-[8px] border-white shadow-[0_30px_60px_-30px_rgba(6,24,47,0.6)]">
            <FallbackImg
              srcs={[...officialFacility[2], photoBuilding]}
              alt="Albert Pharmaceuticals building with the illuminated A logo"
              width={1000}
              height={667}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-[1400ms] ease-[var(--ease-out-expo)] hover:scale-105"
            />
          </div>

          <div className="absolute right-0 top-[8%] z-10 hidden max-w-[220px] rounded-2xl bg-white p-4 shadow-[0_24px_50px_-20px_rgba(6,24,47,0.4)] ring-1 ring-line sm:flex sm:items-start sm:gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand text-white">
              <Icon name="shield" size={20} />
            </span>
            <p className="text-[12.5px] leading-snug text-slate">
              <strong className="block text-[13.5px] text-ink">ISO 9001:2015</strong>
              QMS standard referenced in our Quality Policy
            </p>
          </div>
        </Reveal>

        {/* Copy */}
        <div>
          <Reveal delay={80}>
            <h2 className="font-display text-balance text-[clamp(32px,3.8vw,52px)] font-medium leading-[1.04] tracking-[-0.02em] text-ink">
              Healing is the whole point.
            </h2>
          </Reveal>
          <Reveal delay={140}>
            <blockquote className="font-display relative mt-8 border-l-2 border-teal pl-6 text-[clamp(19px,1.8vw,24px)] italic leading-[1.5] text-navy">
              “…the sole meaning of life for us is to serve the humanity by healing the suffering and oppressed, regardless of religion
              and region.”
            </blockquote>
          </Reveal>

          <Reveal delay={200} className="mt-10">
            <div role="tablist" aria-label="Mission, vision and quality policy" className="inline-flex rounded-full bg-mist p-1.5">
              {tabs.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  role="tab"
                  aria-selected={tab === t.id}
                  onClick={() => setTab(t.id)}
                  className={cx(
                    "h-10 rounded-full px-4 text-[13px] font-semibold transition-all duration-300 sm:px-5",
                    tab === t.id ? "bg-white text-navy shadow-[0_6px_16px_-8px_rgba(6,24,47,0.5)]" : "text-slate hover:text-navy",
                  )}
                >
                  {t.label}
                </button>
              ))}
            </div>
            <p key={current.id} role="tabpanel" className="animate-slide-up mt-6 min-h-[112px] max-w-[540px] text-[16.5px] leading-[1.75] text-slate">
              {current.text}
            </p>
          </Reveal>

          <Reveal delay={260} className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button href={`${company.site}/about-us/`} external variant="dark" icon="arrowUpRight">
              Read our full story
            </Button>
            <Button href="#contact" variant="outline">
              Talk to the team
            </Button>
          </Reveal>
        </div>
      </div>

    </section>
    <Values />
    </>
  );
}

const values = [
  { n: 3, icon: valueIcon3, title: "Team Oriented", text: "A people-oriented company where good work is recognised and rewarded." },
  { n: 4, icon: valueIcon4, title: "Participative Decision Making", text: "Employees take part in management processes and have a real say." },
  { n: 5, icon: valueIcon5, title: "Relationship Building", text: "Long-standing relationships built on trust, respect and honesty." },
  { n: 6, icon: valueIcon6, title: "Reliable", text: "Dedicated to quality excellence. We do what we say and keep promises." },
  { n: 1, icon: valueIcon1, title: "Concern for Society", text: "A responsibility to improve the quality of lives and the environment around us." },
  { n: 2, icon: valueIcon2, title: "Innovation", text: "Adopting innovation in products, systems, customer experience and technology." },
];

function Values() {
  return (
    <section id="values" className="relative isolate overflow-hidden bg-navy py-24 text-white sm:py-32">
      <div className="mx-auto max-w-[1440px] px-5 lg:px-10">
        <img src={hexPattern} alt="" aria-hidden="true" loading="lazy" className="hex-overlay pointer-events-none absolute inset-0 -z-10 h-full w-full object-cover opacity-40" />

        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <Reveal delay={80}>
              <h3 className="font-display text-[clamp(32px,3.8vw,52px)] font-medium leading-[1.05] tracking-[-0.02em]">
                Six values. One standard.
              </h3>
            </Reveal>
          </div>
          <Reveal delay={140}>
            <p className="max-w-[360px] text-[15px] leading-[1.7] text-white/60">How the Albert team works — with each other, with partners and with the communities it serves.</p>
          </Reveal>
        </div>

        <ul className="mt-14 grid gap-x-10 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {values.map((v, i) => (
            <Reveal as="li" key={v.title} delay={(i % 3) * 90} className="group flex gap-5">
              <span className="flex h-[72px] w-[72px] shrink-0 items-center justify-center rounded-2xl bg-white p-3 transition-transform duration-500 group-hover:-translate-y-1.5"><FallbackImg srcs={[officialValueIcon(v.n), v.icon]} alt="" referrerPolicy="no-referrer" loading="lazy" className="h-full w-full object-contain" /></span>
              <div>
                <h4 className="font-display text-[21px] font-semibold leading-tight">{v.title}</h4>
                <p className="mt-2 text-[14.5px] leading-[1.65] text-white/60">{v.text}</p>
              </div>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
