import { categories, company } from "../data/products";
import { logoTaglineWhite } from "../assets";
import { useStore } from "../store";
import { Icon } from "./Icon";

const nav = [
  ["Home", "#top"],
  ["About Us", "#story"],
  ["Products", "#products"],
  ["Categories", "#categories"],
  ["Quality", "#trust"],
  ["Contact", "#contact"],
] as const;

export function Footer() {
  const { browseCategory } = useStore();
  const social = [
    ["facebook", company.social.facebook, "Facebook"],
    ["instagram", company.social.instagram, "Instagram"],
    ["linkedin", company.social.linkedin, "LinkedIn"],
    ["x", company.social.twitter, "X (Twitter)"],
  ] as const;

  return (
    <footer className="relative isolate overflow-hidden bg-ink text-white">

      <div className="mx-auto max-w-[1440px] px-5 pb-10 pt-20 lg:px-10 lg:pt-24">
        <div className="grid gap-14 lg:grid-cols-[1.4fr_0.8fr_1fr_1.1fr]">
          <div>
            <img src={logoTaglineWhite} alt="Albert Pharmaceuticals — Heal, Serve, Forever" width={700} height={254} loading="lazy" className="h-auto w-[210px]" />
            <p className="mt-7 max-w-[360px] text-[14.5px] leading-[1.75] text-white/60">
              Committed to serving the community by continuously investing in quality of life and maintaining the quality standards of our
              healthcare facility.
            </p>
            <div className="mt-7 flex gap-2.5">
              {social.map(([icon, href, label]) => (
                <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={`Albert Pharma on ${label}`} className="flex h-11 w-11 items-center justify-center rounded-full border border-white/15 text-white/75 transition-all duration-300 hover:-translate-y-0.5 hover:border-white hover:bg-white hover:text-ink">
                  <Icon name={icon} size={18} />
                </a>
              ))}
            </div>
          </div>

          <nav aria-label="Footer">
            <h3 className="text-[14px] font-semibold text-white">Explore</h3>
            <ul className="mt-6 space-y-3.5">
              {nav.map(([l, h]) => (
                <li key={l}>
                  <a href={h} className="text-[14.5px] text-white/70 transition-colors hover:text-white">{l}</a>
                </li>
              ))}
              <li>
                <a href={`${company.site}/csr/`} target="_blank" rel="noopener noreferrer" className="text-[14.5px] text-white/70 transition-colors hover:text-white">CSR</a>
              </li>
              <li>
                <a href={`${company.site}/careers/`} target="_blank" rel="noopener noreferrer" className="text-[14.5px] text-white/70 transition-colors hover:text-white">Careers</a>
              </li>
            </ul>
          </nav>

          <div>
            <h3 className="text-[14px] font-semibold text-white">Care areas</h3>
            <ul className="mt-6 space-y-3.5">
              {categories.map((c) => (
                <li key={c.id}>
                  <button type="button" onClick={() => browseCategory(c.id)} className="text-left text-[14.5px] text-white/70 transition-colors hover:text-white">
                    {c.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-[14px] font-semibold text-white">Find us</h3>
            <ul className="mt-6 space-y-4 text-[14.5px] text-white/70">
              <li>
                <a href={company.phoneHref} className="flex items-center gap-3 transition-colors hover:text-white"><Icon name="phone" size={17} className="text-teal" />{company.phone}</a>
              </li>
              <li>
                <a href={`mailto:${company.email}`} className="flex items-center gap-3 transition-colors hover:text-white"><Icon name="mail" size={17} className="text-teal" />{company.email}</a>
              </li>
              <li>
                <a href={company.headOffice} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 transition-colors hover:text-white"><Icon name="pin" size={17} className="text-teal" />Head office map</a>
              </li>
              <li>
                <a href={company.plant} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 transition-colors hover:text-white"><Icon name="factory" size={17} className="text-teal" />Plant map</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-white/10 pt-8 text-[12.5px] text-white/45 md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} {company.legal} All rights reserved.</p>
          <p className="max-w-[560px] md:text-right">
            Product information is for general reference only — consult a healthcare professional before use. Homepage redesign concept
            built for internal presentation.
          </p>
        </div>
      </div>
    </footer>
  );
}
