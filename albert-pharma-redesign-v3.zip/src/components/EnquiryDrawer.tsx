import { company, getProduct } from "../data/products";
import { useEscape } from "../hooks";
import { useStore } from "../store";
import { Icon } from "./Icon";
import { ProductVisual } from "./ui";

export function EnquiryDrawer() {
  const { drawerOpen, setDrawerOpen, items, setQty, remove, clear, count, notify } = useStore();
  useEscape(drawerOpen, () => setDrawerOpen(false));
  if (!drawerOpen) return null;

  const entries = Object.entries(items)
    .map(([slug, qty]) => ({ product: getProduct(slug)!, qty }))
    .filter((e) => e.product);

  const sendEnquiry = () => {
    const lines = entries.map((e) => `- ${e.product.name} (${e.product.generic}, ${e.product.pack}) × ${e.qty}`);
    const body = `Hello Albert Pharma team,\n\nI would like to enquire about the following products:\n\n${lines.join("\n")}\n\nPlease get in touch with availability and next steps.\n\nThank you.`;
    window.location.href = `mailto:${company.email}?subject=${encodeURIComponent("Product enquiry — Albert Pharma")}&body=${encodeURIComponent(body)}`;
    notify("Enquiry prepared — opening your email app");
  };

  return (
    <div className="fixed inset-0 z-[85]" role="dialog" aria-modal="true" aria-label="Enquiry list">
      <div className="animate-fade-in absolute inset-0 bg-ink/60 backdrop-blur-sm" onClick={() => setDrawerOpen(false)} />
      <aside className="animate-drawer-in absolute inset-y-0 right-0 flex w-full max-w-[480px] flex-col bg-white shadow-[-40px_0_80px_-30px_rgba(0,0,0,0.5)]">
        <header className="flex items-center justify-between border-b border-line px-6 py-5">
          <div>
            <h2 className="font-display text-[26px] font-semibold leading-none text-ink">Enquiry list</h2>
            <p className="mt-1.5 text-[12.5px] text-slate">{count === 0 ? "Nothing added yet" : `${count} ${count === 1 ? "item" : "items"} · ${entries.length} ${entries.length === 1 ? "product" : "products"}`}</p>
          </div>
          <button type="button" onClick={() => setDrawerOpen(false)} aria-label="Close enquiry list" className="flex h-11 w-11 items-center justify-center rounded-full bg-mist text-ink transition-colors hover:bg-ink hover:text-white">
            <Icon name="close" size={19} />
          </button>
        </header>

        {entries.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-10 text-center">
            <span className="flex h-24 w-24 items-center justify-center rounded-full bg-[radial-gradient(circle,#e4f1fb,#f1f6fa)] text-brand">
              <Icon name="bag" size={40} strokeWidth={1.3} />
            </span>
            <p className="font-display mt-7 text-[28px] font-medium leading-tight text-ink">Your list is empty</p>
            <p className="mt-3 max-w-[300px] text-[14.5px] leading-relaxed text-slate">
              Browse the range and add the products you’re interested in. You can send them to our team as a single enquiry.
            </p>
            <a
              href="#products"
              onClick={() => setDrawerOpen(false)}
              className="mt-8 inline-flex h-12 items-center gap-2 rounded-full bg-ink px-7 text-sm font-semibold text-white transition-colors hover:bg-navy"
            >
              Browse products <Icon name="arrowRight" size={16} />
            </a>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-line overflow-y-auto px-6">
              {entries.map(({ product, qty }) => (
                <li key={product.slug} className="flex gap-4 py-5">
                  <div className="h-[88px] w-[100px] shrink-0 overflow-hidden rounded-2xl bg-[radial-gradient(ellipse_at_50%_35%,#fff,#e6eef4)]">
                    <ProductVisual product={product} className="h-full w-full p-2" />
                  </div>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-display text-[20px] font-semibold leading-tight text-ink">{product.name}</p>
                        <p className="truncate text-[12.5px] text-slate">{product.generic}</p>
                        <p className="text-[12px] text-slate/70">{product.pack}</p>
                      </div>
                      <button type="button" onClick={() => remove(product.slug)} aria-label={`Remove ${product.name}`} className="rounded-full p-2 text-slate transition-colors hover:bg-mist hover:text-ink">
                        <Icon name="trash" size={16} />
                      </button>
                    </div>
                    <div className="mt-auto inline-flex w-fit items-center rounded-full border border-line">
                      <button type="button" onClick={() => setQty(product.slug, qty - 1)} aria-label={`Decrease ${product.name}`} className="flex h-9 w-9 items-center justify-center rounded-full text-navy transition-colors hover:bg-mist">
                        <Icon name="minus" size={15} />
                      </button>
                      <span className="w-8 text-center text-[14px] font-bold text-ink" aria-live="polite">{qty}</span>
                      <button type="button" onClick={() => setQty(product.slug, qty + 1)} aria-label={`Increase ${product.name}`} className="flex h-9 w-9 items-center justify-center rounded-full text-navy transition-colors hover:bg-mist">
                        <Icon name="plus" size={15} />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <footer className="border-t border-line bg-mist/60 px-6 pb-6 pt-5">
              <p className="text-[12.5px] leading-relaxed text-slate">
                Pricing and availability are confirmed by the Albert team. Online ordering is part of the future platform — for now your list opens as a ready-written email.
              </p>
              <button type="button" onClick={sendEnquiry} className="mt-4 flex h-14 w-full items-center justify-center gap-2.5 rounded-full bg-brand hover:bg-navy text-[15px] font-semibold text-white shadow-[0_12px_30px_-10px_rgba(0,104,180,0.8)] transition-transform duration-300 hover:-translate-y-0.5">
                <Icon name="send" size={18} /> Send enquiry
              </button>
              <button type="button" onClick={clear} className="mt-3 w-full text-center text-[13px] font-semibold text-slate transition-colors hover:text-ink">
                Clear list
              </button>
            </footer>
          </>
        )}
      </aside>
    </div>
  );
}
