import { company } from "../data/products";
import { Icon } from "./Icon";

export function AnnouncementBar() {
  return (
    <div className="relative z-50 bg-ink text-[12px] text-white/70">
      <div className="mx-auto flex h-10 max-w-[1440px] items-center justify-between gap-6 px-5 lg:px-10">
        <p className="hidden items-center gap-2.5 whitespace-nowrap font-medium tracking-wide text-white/85 sm:flex">
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-teal opacity-70" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-teal" />
          </span>
          <span className="font-display italic text-aqua">{company.tagline}</span>
          <span className="hidden h-3 w-px bg-white/20 lg:block" />
          <span className="hidden tracking-[0.04em] lg:inline">Pakistan’s pharmaceutical partner</span>
        </p>

        <div className="flex w-full items-center justify-between gap-5 sm:w-auto sm:justify-end">
          <a href={company.phoneHref} className="flex items-center gap-2 whitespace-nowrap transition-colors hover:text-white">
            <Icon name="phone" size={13} />
            <span className="font-semibold tracking-wide">{company.phone}</span>
          </a>
          <a href={`mailto:${company.email}`} className="hidden items-center gap-2 whitespace-nowrap transition-colors hover:text-white lg:flex">
            <Icon name="mail" size={13} />
            {company.email}
          </a>
          <div className="flex items-center gap-3.5 border-l border-white/15 pl-5">
            {(
              [
                ["facebook", company.social.facebook, "Facebook"],
                ["instagram", company.social.instagram, "Instagram"],
                ["linkedin", company.social.linkedin, "LinkedIn"],
                ["x", company.social.twitter, "X (Twitter)"],
              ] as const
            ).map(([icon, href, label]) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`Albert Pharma on ${label}`}
                className="transition-colors hover:text-white"
              >
                <Icon name={icon} size={14} />
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
