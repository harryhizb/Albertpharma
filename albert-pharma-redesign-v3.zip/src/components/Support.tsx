import { useState, type FormEvent } from "react";
import { company } from "../data/products";
import { Reveal, cx } from "./ui";
import { Icon, type IconName } from "./Icon";

const channels: { icon: IconName; title: string; value: string; href: string; external?: boolean }[] = [
  { icon: "phone", title: "Call us", value: company.phone, href: company.phoneHref },
  { icon: "mail", title: "Email us", value: company.email, href: `mailto:${company.email}` },
  { icon: "pin", title: "Head office", value: "Open in Google Maps", href: company.headOffice, external: true },
  { icon: "factory", title: "Manufacturing plant", value: "Open in Google Maps", href: company.plant, external: true },
];

const topics = ["Product information", "Availability & ordering", "Partnership / distribution", "General enquiry"];

export function Support() {
  const [state, setState] = useState<"idle" | "sending" | "sent">("idle");
  const [name, setName] = useState("");

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setName(String(fd.get("name") ?? ""));
    setState("sending");
    // Demo only — no backend in this presentation build.
    window.setTimeout(() => setState("sent"), 900);
  };

  const field =
    "h-[54px] w-full rounded-2xl border border-line bg-white px-4 text-[15px] text-ink outline-none transition-[border-color,box-shadow] duration-300 placeholder:text-slate/45 focus:border-brand focus:shadow-[0_0_0_4px_rgba(0,104,180,0.12)]";

  return (
    <section id="contact" className="relative bg-mist py-24 sm:py-32">
      <div className="mx-auto grid max-w-[1440px] gap-14 px-5 lg:grid-cols-[1fr_1.05fr] lg:gap-20 lg:px-10">
        <div>
          <Reveal delay={80}>
            <h2 className="font-display text-balance text-[clamp(32px,3.8vw,52px)] font-medium leading-[1.04] tracking-[-0.02em] text-ink">
              Questions? We’re here to help.
            </h2>
          </Reveal>
          <Reveal delay={140}>
            <p className="mt-6 max-w-[480px] text-[16.5px] leading-[1.75] text-slate">
              Reach the Albert team about products, availability or partnerships. Pick the channel that suits you — or send a note and we’ll
              get back to you.
            </p>
          </Reveal>

          <ul className="mt-10 grid gap-3 sm:grid-cols-2">
            {channels.map((c, i) => (
              <Reveal as="li" key={c.title} delay={i * 70}>
                <a
                  href={c.href}
                  {...(c.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                  className="group flex h-full items-center gap-4 rounded-[22px] border border-line bg-white p-5 transition-[transform,box-shadow,border-color] duration-500 ease-[var(--ease-out-expo)] hover:-translate-y-1 hover:border-transparent hover:shadow-[0_28px_44px_-28px_rgba(6,24,47,0.45)]"
                >
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-mist text-brand transition-colors duration-500 group-hover:bg-brand group-hover:text-white">
                    <Icon name={c.icon} size={21} />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[13px] font-medium text-slate">{c.title}</span>
                    <span className="mt-1 block truncate text-[14.5px] font-semibold text-ink">{c.value}</span>
                  </span>
                </a>
              </Reveal>
            ))}
          </ul>

          <Reveal delay={200} className="mt-8 flex items-start gap-3 rounded-2xl border border-dashed border-brand/30 bg-white/50 p-5">
            <Icon name="headset" size={20} className="mt-0.5 shrink-0 text-brand" />
            <p className="text-[13.5px] leading-relaxed text-slate">
              <strong className="text-ink">Shopping made simple:</strong> add products to your enquiry list while you browse — then send the whole list to us in one message.
            </p>
          </Reveal>
        </div>

        <Reveal delay={120}>
          <div className="relative overflow-hidden rounded-[24px] border border-line bg-white p-7 shadow-[0_40px_70px_-40px_rgba(6,24,47,0.4)] sm:p-10">
            {state === "sent" ? (
              <div className="animate-scale-in relative flex min-h-[460px] flex-col items-center justify-center text-center">
                <span className="flex h-20 w-20 items-center justify-center rounded-full bg-brand text-white">
                  <Icon name="check" size={34} strokeWidth={2.2} />
                </span>
                <h3 className="font-display mt-7 text-[32px] font-medium leading-tight text-ink">Thank you{name ? `, ${name.split(" ")[0]}` : ""}.</h3>
                <p className="mt-3 max-w-[340px] text-[15px] leading-relaxed text-slate">
                  Your message is on its way to the Albert team. We’ll reply as soon as we can.
                </p>
                <p className="mt-6 rounded-full bg-mist px-4 py-2 text-[11.5px] font-semibold text-slate">Demo form — the live platform will connect this to the team’s inbox.</p>
                <button type="button" onClick={() => setState("idle")} className="mt-6 text-[13.5px] font-semibold text-brand hover:underline">
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={submit} className="relative">
                <h3 className="font-display text-[30px] font-semibold leading-tight text-ink">Send us a message</h3>
                <p className="mt-2 text-[14px] text-slate">All fields marked * are required.</p>

                <div className="mt-8 grid gap-4 sm:grid-cols-2">
                  <label className="block">
                    <span className="mb-2 block text-[12.5px] font-semibold text-ink">Full name *</span>
                    <input name="name" required autoComplete="name" placeholder="Your name" className={field} />
                  </label>
                  <label className="block">
                    <span className="mb-2 block text-[12.5px] font-semibold text-ink">Email *</span>
                    <input name="email" type="email" required autoComplete="email" placeholder="you@example.com" className={field} />
                  </label>
                </div>

                <fieldset className="mt-5">
                  <legend className="mb-2 text-[12.5px] font-semibold text-ink">I’m interested in</legend>
                  <div className="flex flex-wrap gap-2">
                    {topics.map((t, i) => (
                      <label key={t} className="cursor-pointer">
                        <input type="radio" name="topic" value={t} defaultChecked={i === 0} className="peer sr-only" />
                        <span className="inline-flex h-10 items-center rounded-full border border-line px-4 text-[13px] font-semibold text-slate transition-all duration-300 peer-checked:border-navy peer-checked:bg-navy peer-checked:text-white peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-sky hover:border-navy/40">
                          {t}
                        </span>
                      </label>
                    ))}
                  </div>
                </fieldset>

                <label className="mt-5 block">
                  <span className="mb-2 block text-[12.5px] font-semibold text-ink">Message *</span>
                  <textarea name="message" required rows={5} placeholder="How can we help?" className={cx(field, "h-auto resize-none py-3.5 leading-relaxed")} />
                </label>

                <button
                  type="submit"
                  disabled={state === "sending"}
                  className="group mt-7 flex h-14 w-full items-center justify-center gap-2.5 rounded-full bg-brand hover:bg-navy text-[15px] font-semibold text-white shadow-[0_14px_32px_-12px_rgba(0,104,180,0.8)] transition-[background-position,opacity] duration-500 hover:bg-right disabled:opacity-70"
                >
                  {state === "sending" ? (
                    <>
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" /> Sending…
                    </>
                  ) : (
                    <>
                      Send message <Icon name="send" size={17} className="transition-transform duration-500 group-hover:translate-x-1" />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
