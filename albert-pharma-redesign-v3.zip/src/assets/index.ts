/**
 * Central asset registry.
 * All imagery below is sourced from albertpharma.com (product packs, logo,
 * facility photography, value icons) and optimised to WebP.
 * Assets are imported (not served from /public) so the single-file build inlines them.
 */
const productFiles = import.meta.glob("./products/*.{webp,png,jpg,jpeg}", {
  eager: true,
  query: "?url",
  import: "default",
}) as Record<string, string>;

export const productImage = (slug: string): string | undefined => {
  for (const ext of ["png", "webp", "jpg", "jpeg"]) {
    const hit = productFiles[`./products/${slug}.${ext}`];
    if (hit) return hit;
  }
  return undefined;
};

/* ------------------------------------------------------------------ *
 * Official albertpharma.com imagery, loaded straight from the live site.
 * Every URL below was read from the live pages (home, /products/, /about-us/, /etogesic/).
 * Local files in this folder are the offline fallback if a remote image fails.
 * ------------------------------------------------------------------ */
export const OFFICIAL = "https://albertpharma.com";
const up = (path: string) => `${OFFICIAL}/wp-content/uploads/${path}`;
const theme = (path: string) => `${OFFICIAL}/wp-content/themes/albert/${path}`;

/** Pack artwork confirmed on the official product pages. Others come from `npm run fetch-assets`. */
export const officialPack: Record<string, string> = {
  etogesic: up("2024/06/Etogesic-01.png"),
  fobert: up("2024/06/fobert-40.png"),
  alzacin: up("2024/06/alzacin-Box-1-1.png"),
};

/** Facility photographs from the About page gallery (full size first, then the 400px version listed on the site). */
export const officialFacility = [1, 2, 3].map((n) => [up(`2018/11/${n}.jpg`), up(`2018/11/${n}-400x266.jpg`)]);

/** "Our Featured Brands" banners from the live site footer carousel. */
export const officialFeatured = [2, 3, 4, 5, 6].map((n) => theme(`images/featuredImages/${n}.png`));

/** Core-value icons (1–6) from the live Our Values section. */
export const officialValueIcon = (n: number) => theme(`images/icons/${n}.png`);

export const packSources = (slug: string): string[] =>
  [officialPack[slug], productImage(slug)].filter(Boolean) as string[];

export { default as logoFullNavy } from "./brand/logo3-navy.webp";
export { default as logoFullWhite } from "./brand/logo3-white.webp";
export { default as logoMarkNavy } from "./brand/logo4-navy.webp";
export { default as logoMarkWhite } from "./brand/logo4-white.webp";
export { default as logoTaglineWhite } from "./brand/logo5-white.webp";
export { default as brandMark } from "./brand/mark.webp";

export { default as photoCorridor } from "./photos/corridor.webp";
export { default as photoDoor } from "./photos/door.webp";
export { default as photoBuilding } from "./photos/building.webp";
export { default as photoLab } from "./photos/lab.webp";

export { default as valueIcon1 } from "./values/v1.webp";
export { default as valueIcon2 } from "./values/v2.webp";
export { default as valueIcon3 } from "./values/v3.webp";
export { default as valueIcon4 } from "./values/v4.webp";
export { default as valueIcon5 } from "./values/v5.webp";
export { default as valueIcon6 } from "./values/v6.webp";

/**
 * Brand hexagon / molecule motif (echoes the hexagon artwork on albertpharma.com).
 * Generated as an inline SVG so it stays crisp at any size and costs ~nothing.
 */
function buildHexPattern(): string {
  const r = 62;
  const w = 1600;
  const h = 900;
  const dx = r * 1.5;
  const dy = r * Math.sqrt(3);
  let d = "";
  let nodes = "";
  for (let i = 0; i * dx < w + r; i++) {
    for (let j = -1; j * dy < h + r; j++) {
      const cx = i * dx;
      const cy = j * dy + (i % 2 ? dy / 2 : 0);
      const pts = Array.from({ length: 6 }, (_, k) => {
        const a = (Math.PI / 3) * k;
        return `${(cx + r * Math.cos(a)).toFixed(1)} ${(cy + r * Math.sin(a)).toFixed(1)}`;
      });
      d += `M${pts.join("L")}Z`;
      if ((i * 7 + j * 3) % 11 === 0) {
        nodes += `<circle cx='${cx.toFixed(1)}' cy='${cy.toFixed(1)}' r='4' fill='white' stroke='none'/>`;
      }
    }
  }
  const svg =
    `<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}' viewBox='0 0 ${w} ${h}'>` +
    `<defs><radialGradient id='g' cx='78%' cy='42%' r='62%'><stop offset='0' stop-color='white'/><stop offset='1' stop-color='black'/></radialGradient>` +
    `<mask id='m'><rect width='${w}' height='${h}' fill='url(#g)'/></mask></defs>` +
    `<g mask='url(#m)' stroke='white' stroke-opacity='.5' stroke-width='1.3' fill='none'><path d='${d}'/>${nodes}</g></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

export const hexPattern = buildHexPattern();
