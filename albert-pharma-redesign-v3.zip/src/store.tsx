import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { getProduct, type CategoryId } from "./data/products";

/**
 * Lightweight app store (no external state library).
 * Albert's source site publishes no prices, so the "cart" is an enquiry list:
 * visitors collect products and send a single enquiry to the company.
 */
interface Toast {
  id: number;
  message: string;
  action?: { label: string; run: () => void };
}

interface StoreValue {
  items: Record<string, number>;
  count: number;
  add: (slug: string) => void;
  setQty: (slug: string, qty: number) => void;
  remove: (slug: string) => void;
  clear: () => void;

  drawerOpen: boolean;
  setDrawerOpen: (v: boolean) => void;

  searchOpen: boolean;
  setSearchOpen: (v: boolean) => void;

  quickView: string | null;
  openQuickView: (slug: string) => void;
  closeQuickView: () => void;

  filter: CategoryId | "all";
  setFilter: (c: CategoryId | "all") => void;
  /** set a category filter and smooth-scroll to the product grid */
  browseCategory: (c: CategoryId | "all") => void;

  toast: Toast | null;
  notify: (message: string, action?: Toast["action"]) => void;
}

const Ctx = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Record<string, number>>({});
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [quickView, setQuickView] = useState<string | null>(null);
  const [filter, setFilter] = useState<CategoryId | "all">("all");
  const [toast, setToast] = useState<Toast | null>(null);
  const timer = useRef<number | undefined>(undefined);

  const notify = useCallback((message: string, action?: Toast["action"]) => {
    window.clearTimeout(timer.current);
    setToast({ id: Date.now(), message, action });
    timer.current = window.setTimeout(() => setToast(null), 3600);
  }, []);

  const add = useCallback(
    (slug: string) => {
      setItems((prev) => ({ ...prev, [slug]: (prev[slug] ?? 0) + 1 }));
      const p = getProduct(slug);
      notify(`${p?.name ?? "Product"} added to your enquiry list`, {
        label: "View list",
        run: () => setDrawerOpen(true),
      });
    },
    [notify],
  );

  const setQty = useCallback((slug: string, qty: number) => {
    setItems((prev) => {
      const next = { ...prev };
      if (qty <= 0) delete next[slug];
      else next[slug] = Math.min(qty, 99);
      return next;
    });
  }, []);

  const remove = useCallback((slug: string) => setQty(slug, 0), [setQty]);
  const clear = useCallback(() => setItems({}), []);

  const browseCategory = useCallback((c: CategoryId | "all") => {
    setFilter(c);
    requestAnimationFrame(() => {
      document.getElementById("products")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, []);

  // Lock body scroll while an overlay is open
  const overlayOpen = drawerOpen || searchOpen || quickView !== null;
  useEffect(() => {
    document.body.style.overflow = overlayOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [overlayOpen]);

  const value = useMemo<StoreValue>(
    () => ({
      items,
      count: Object.values(items).reduce((a, b) => a + b, 0),
      add,
      setQty,
      remove,
      clear,
      drawerOpen,
      setDrawerOpen,
      searchOpen,
      setSearchOpen,
      quickView,
      openQuickView: setQuickView,
      closeQuickView: () => setQuickView(null),
      filter,
      setFilter,
      browseCategory,
      toast,
      notify,
    }),
    [items, add, setQty, remove, clear, drawerOpen, searchOpen, quickView, filter, browseCategory, toast, notify],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useStore must be used inside StoreProvider");
  return v;
}
