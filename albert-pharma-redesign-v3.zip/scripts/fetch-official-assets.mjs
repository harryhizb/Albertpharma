#!/usr/bin/env node
/**
 * Downloads the official pack artwork from albertpharma.com into src/assets/products/<slug>.<ext>.
 * Run on a machine with internet access:   npm run fetch-assets
 *
 * For every product page listed in src/data/products.ts it takes the first image under /wp-content/uploads/
 * (leaflets, PDFs and logos skipped), saves it, and removes the generated stand-in <slug>.webp.
 * Review the report at the end: any product it could not resolve keeps its stand-in / placeholder.
 */
import { readFile, writeFile, mkdir, rm } from "node:fs/promises";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const src = await readFile(path.join(root, "src/data/products.ts"), "utf8");
const outDir = path.join(root, "src/assets/products");
await mkdir(outDir, { recursive: true });

// slug + page url pairs:  slug: "alzacin", ... url: site("alzacin")
const items = [...src.matchAll(/slug:\s*"([^"]+)"[\s\S]*?url:\s*site\("([^"]+)"\)/g)].map((m) => ({ slug: m[1], page: `https://albertpharma.com/${m[2]}/` }));

const UA = { "user-agent": "Mozilla/5.0 (asset-fetch for Albert Pharma redesign)" };
const report = [];

for (const { slug, page } of items) {
  try {
    const html = await (await fetch(page, { headers: UA })).text();
    const urls = [...html.matchAll(/https?:\/\/(?:www\.)?albertpharma\.com\/wp-content\/uploads\/[^"'\s)<>]+?\.(?:png|jpe?g|webp)/gi)].map((m) => m[0]);
    const pick = urls.find((u) => !/leaflet|logo|icon|banner/i.test(u));
    if (!pick) { report.push(`✗ ${slug}: no image found on ${page}`); continue; }
    const res = await fetch(pick, { headers: UA });
    if (!res.ok) { report.push(`✗ ${slug}: ${pick} -> HTTP ${res.status}`); continue; }
    const ext = path.extname(new URL(pick).pathname).toLowerCase().replace("jpeg", "jpg");
    await writeFile(path.join(outDir, `${slug}${ext}`), Buffer.from(await res.arrayBuffer()));
    await rm(path.join(outDir, `${slug}.webp`), { force: true });
    report.push(`✓ ${slug}: ${pick}`);
  } catch (e) {
    report.push(`✗ ${slug}: ${e.message}`);
  }
}
console.log(report.join("\n"));
console.log("\nOpen each pack once to confirm it is the right product before presenting.");
