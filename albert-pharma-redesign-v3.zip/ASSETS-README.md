# Images: official albertpharma.com first, local files as fallback

Loaded live from albertpharma.com (URLs read from the live pages; see src/assets/index.ts):
- Pack artwork: Etogesic, Fobert, Alzacin (confirmed on their product pages) — these are the three hero packs
- Facility photos: /wp-content/uploads/2018/11/1.jpg, 2.jpg, 3.jpg (falls back to the 400px versions listed on the site)
- Core-value icons 1-6 and the five "Our Featured Brands" banners (theme/images/...)

Remaining pack artwork: run `npm run fetch-assets` on a machine with internet. It reads each product page,
saves the pack image to src/assets/products/<slug>.<ext> and deletes the generated stand-in. Open each pack once
to confirm it is the right product.

Anything still marked "STAND-IN" in src/assets (brand/, photos/, values/, products/) was generated because the
original zip had no image files; overwrite those with your real files.
